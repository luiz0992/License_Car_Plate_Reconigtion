# Code of Conduct 

The Shell Code of Conduct can be found on the page of the [Ethics-and Compliance Office](https://hub.shell.com/sitepage/369137/ethics-and-compliance-homepage?src=ess).