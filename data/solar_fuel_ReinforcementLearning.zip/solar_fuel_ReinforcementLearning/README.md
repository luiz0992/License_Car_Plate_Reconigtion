# Solar Fuel Optimization by Reinforcement Learning 

## Introduction

This repo is for the research project on solar fuel optimization problem by reinforcement learning method.

We have defined a basic and simplified trial problem to see if the reinforcement learning can solve the optimization of the energy systems: Building a hydrogen plant based on solar energy via water electrolysis. The system includes: solar PV, water electrolyzer, battery for electricity storage and H2 storage. The aim is to make a design that produces a certain amount of H2 per year with minimum cost. It allows curtailing some electricity to the outlet (energy discarded). When a stable supply of H2 is desired, we will need either battery or H2 storage depending on the cost of the two options. It is first designed to compute the sizing of the solar PV based on the demand, but in our solution, we use the fixed solar capacity so the solar input is a given. (scaling up doesn’t need too much additional cost). 


## Current Implementation

<img src="data/figures/sketch.png">

* Building a hydrogen plant based on solar energy via water electrolysis.  This is a standalone system and not connected to power grid.  The use of H2 is outside the boundary. 
* Make a design that produced a certain amount of H2 per year with minimum cost
* Allows curtailing some electricity
* Battery or H2 storage depending on the cost of the two options
* We only consider the cost of production, and no price is modelled. 
* For this trial, the technical aspects are simplified.  For example, H2 compression and energy loss in storage are ignored. 

### In detail, we may consider two cases: 

* Case 1: Hydrogen demand is 365 kton per year, and the demand is fully flexible, i.e., it is not obligated to have H2 supply that is stable or meeting a predefined demand profile. It can vary through the year.
* Case 2: Hydrogen demand is constantly 1 kton per day.


## Model

Inputs to the model: 

* CAPEX and OPEX of solar PV, electrolyzer, battery and H2 storage (TBI), which is linear to the installed capacity 
* Hourly output profile of solar PV of 1 year (GW per GWp capacity) 
* Efficiency of electrolyzer from power to H2 (TBI)
* Other operational constraints, if needed (e.g., non-negative battery, the minimum load factor of electrolyzer) 

Output of the model: 

* Optimal sizing of the components (TBI)
* Optimal operation of electrolyzer (on/off, load factor) and storage (charging and discharging) 

## Repository Overview

The example of running pipelines can be found in the folder [`notebooks`](https://github.com/sede-x/solar_fuel_ReinforcementLearning/tree/luiz-update-readme/notebooks) which contains jupyter notebooks that can be executed once your local IDE is set-up.
More generally, folder contents are as follows:

* `data` - folder where the source data and figures are stored.
* `notebooks` - folders with jupyter notebooks for analyses and demos;
* `src` - library code containing the machine learning pipelines for iris flower categorization
    * `pipelines` - Folder contains the training and testing pipelines

All other folder and functions are still not implemented.

The framework using the [`stable-baselines3`](https://github.com/DLR-RM/stable-baselines3/blob/master/docs/index.rst) and [`PyTorch`](https://github.com/pytorch/pytorch).

<!-- ## Contributions

We welcome contributions to our project. Contributions are welcome as suggestions of improvements, or as pull requests.

Examples for helpful contributions could be:

* improving the library code for data cleaning/loading
* feedback on the analyses or the prediction experiments
* subject matter input, especially from reservoir botanists

Good first issues and discussions can be found in the [issue tracker](https://github.com/sede-x/base-datascience-tpl/issues). We ask you to be open, considerate and respectful.

The most up-to-date branch is the [dev](https://github.com/sede-x/base-datascience-tpl/tree/dev) branch.

Details on how to set yourself up for contribution can be found in the [contribution guidelines](https://github.com/sede-x/base-datascience-tpl/contributing.md).

**TODO:** this section should specify what kind of contributions the project is open to, and how to contribute. This should at least allow anyone to set up a copy of the repository and continue developing it. Technical details on how to set up builds, pre-commits, testing, CI, etc should be covered in a dedicated location, e.g., `contributing.md`.
The content may coincide with the quick-start guide (see above), in which case only one document is needed. Advanced projects may have substantially different workflows for usage/consumption and contribution/development in which case having separate documentation artefacts is advised. -->

## Project Team

An [overview of our project team](https://github.com/sede-x/solar_fuel_ReinforcementLearning/graphs/contributors).

FP for this project are:
| topic | role | name | Github ID |
| --- | --- | --- | --- |
| Research | Senior Research Scientist | Xiao Fu | @ |
| Research | Research Scientist | Doga Demirhan | @ |
| AI | AI lead | Tina Zhao | @ |
| AI | AI researcher | Boran Han | @ |
| data science |Principal Data Scientist | Christian Michler | @ |
| data science | Data Scientist | Luiz F. G. dos Santos | @luiz0992 |

## About this readme

Project based on the [Shell & NAM cookiecutter data science project template](https://github.com/sede-x/shell-cookiecutters/).
