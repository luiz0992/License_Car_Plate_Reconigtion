from setuptools import setup

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name='rl-sfo',
    version='0.0.3',
    author='Luiz F. G. dos Santos',
    author_email='l.guedesdossantos@shell.com',
    description='Base package for Reinforcement Learning Solar Fuel Optimization package',
    long_description=long_description,
    long_description_content_type="text/markdown",
    url='https://github.com/sede-x/solar_fuel_ReinforcementLearning',
    project_urls = {
        "Bug Tracker": "https://github.com/sede-x/solar_fuel_ReinforcementLearning/issues"
    },
    license='MIT',
)