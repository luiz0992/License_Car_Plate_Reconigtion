import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta

def load_solar_profile(data_path,
                       initial_month,
                       number_of_months,
                       year="TMY P90"):
    """_summary_

    Args:
        data_path (_type_): _description_

    Returns:
        _type_: _description_
    """
    #Step 1. Get the solar input and demand data]
    # def load_data(num_of_months):
    whole_year_supply_df=pd.read_csv(data_path)

    whole_year_supply_df.columns = ['hour index', '1998', '1999', '2000',
                                    '2001', '2002', '2003', '2004', '2005',
                                    '2006', '2007', '2008', '2009', '2010',
                                    '2011', '2012', '2013', '2014', '2015',
                                    '2016', '2017', '2018', 'TMY P50', 'TMY P90']


    whole_year_supply_df.dropna(inplace=True)
    whole_year_supply_df=whole_year_supply_df[['hour index',f'{year}']]
    whole_year_supply_df.rename(columns={f'{year}':'volume'}, inplace=True)
    whole_year_supply_df.rename(columns={'hour index':'hour'}, inplace=True)

    installed_capacity = 16000 #GW
    capacity = 100*1e6
    whole_year_supply_df['volume']=(whole_year_supply_df['volume']/capacity)*installed_capacity

    first_day_of_the_year = datetime.strptime('Jan 01 2022', '%b %d %Y')
    initial_date_train = datetime.strptime(f'{initial_month} 01 2022', '%b %d %Y')
    final_date_train = initial_date_train + relativedelta(months=number_of_months)
    initial_date_hours_train = (initial_date_train - first_day_of_the_year).total_seconds() // 3600
    final_date_hours_train = (final_date_train - first_day_of_the_year).total_seconds() // 3600
    whole_year_supply_list = np.array(whole_year_supply_df['volume'].values, dtype=np.float32)
    whole_year_supply_list = whole_year_supply_list\
                                 [int(initial_date_hours_train):int(final_date_hours_train)]
                                 
    print("Whole Year Supply DF description")
    print("==========================================================")
    print(whole_year_supply_df.iloc[int(initial_date_hours_train):int(final_date_hours_train)].describe())
    print("==========================================================")
    print(f"The sum of the whole energy volume is {whole_year_supply_df['volume'].sum()}")
    return whole_year_supply_list
 