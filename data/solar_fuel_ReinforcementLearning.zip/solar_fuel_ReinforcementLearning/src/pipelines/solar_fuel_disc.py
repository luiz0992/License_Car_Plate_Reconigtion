# -*- coding: utf-8 -*-
"""
Created on Mon Feb 28 13:56:05 2022

Solar fuel optimization using Reinforcement learning


@author: Tina.T.Zhao
Modified by Luiz F. G. dos Santos
"""
# sys.executable
# check if it's under RLgastrading where stable-baseline is installed

import torch
torch.set_num_threads(16)

#import libraries
import os
import sys
import gym
import time
import logging
import numpy as np
import pandas as pd
import argparse
import stable_baselines3
import seaborn as sns; sns.set()
import matplotlib as mpl
import matplotlib.pyplot as plt

# from IPython.display import display
from gym import spaces
from gym.spaces import Box
from tqdm.auto import tqdm
from qbstyles import mpl_style
from stable_baselines3 import PPO
from stable_baselines3.common.callbacks import BaseCallback, EvalCallback
from stable_baselines3.common.env_checker import check_env
from stable_baselines3.common.vec_env import SubprocVecEnv, VecNormalize, VecMonitor
from stable_baselines3.common.monitor import Monitor



_logger = logging.getLogger(__name__)

mpl_style(dark=False)

def parse_parameters() -> list:
    #parse parameters    
    p = argparse.ArgumentParser(prog="RL Solar-H2 Production Pipeline", 
                                formatter_class=argparse.ArgumentDefaultsHelpFormatter, 
                                description="Use reinforcement learning to optmize H2 production "\
                                    "using solar energy")
    p.add_argument("--experiment_name",
                    help="Name of the experiment running",
                    type=str)
    p.add_argument("--eval_freq",
                    help="Frequency of evaluation in training",
                    default=50000,
                    type=int)
    p.add_argument("--steps_scale_factor",
                    help="Scaling factor on the steps learning",
                    default=3500,
                    type=int)
    p.add_argument("--num_of_months",
                    help="Number of months on the training",
                    default=12,
                    type=int)
    
    # extract the parameters from the parser
    args, unknown = p.parse_known_args()
    experiment_name = args.experiment_name
    eval_freq = args.eval_freq
    steps_scale_factor = args.steps_scale_factor
    num_of_months = args.num_of_months

    return experiment_name, eval_freq, steps_scale_factor, num_of_months

def load_solar_profile(data_path,):
    #Step 1. Get the solar input and demand data]
    # def load_data(num_of_months):
    whole_year_supply_df=pd.read_csv(data_path)

    whole_year_supply_df.columns = ['hour index', '1998', '1999', '2000', '2001', '2002', '2003', '2004',
        '2005', '2006', '2007', '2008', '2009', '2010', '2011', '2012', '2013',
        '2014', '2015', '2016', '2017', '2018', 'TMY P50', 'TMY P90']

    whole_year_supply_df.dropna(inplace=True)
    whole_year_supply_df=whole_year_supply_df[['hour index','TMY P90']]
    month_len = len(whole_year_supply_df)/12
    whole_year_supply_df = whole_year_supply_df.iloc[int(5*month_len):int(6*month_len)]# .head(int(len(whole_year_supply_df)/12))
    lenT=len(whole_year_supply_df)
    whole_year_supply_df.rename(columns={'TMY P90':'volume'}, inplace=True)
    whole_year_supply_df.rename(columns={'hour index':'hour'}, inplace=True)

    print(f"The sum of the whole energy volume is {whole_year_supply_df['volume'].sum()}")

    whole_year_supply_df['volume'].sum()/(1100*365) # make the scale similar for daily demand of 1100
    whole_year_supply_df['volume']=whole_year_supply_df['volume']/500000.0 # correct the coefficients

    print(f'The total number of hours {lenT}')  # total number of hours per year
    
    return whole_year_supply_df, lenT

#Set up the environment
# define the environment
class State(object):
     
    def __init__(self, T, solar_in, battery_level, t=0):
        
       # at solar
        self.solar_in = solar_in  #0 solar input level
        self.battery_level = battery_level  #235 stock level

       # self.electrolyzer_converted_to_H2 = 0 # converted H2 level every day
       # self.H2_out = 0  # H2 demand  adding demand to state 
       # self.demand_projection = [0,0,0,0,0,0,0,0,0,0]  #demand_history  # adding demand to state  
       # self.H2storage_level = 0.0  # H2 storage stock level
        
        self.T = T
        self.t = t
        
    def to_array(self):
        return np.concatenate(([self.solar_in], [self.battery_level]),dtype=np.float32)
        
class Action(object):
    def __init__(self):
        
        self.solar_to_electrolyzer = 0
        self.solar_to_curtail= 0 
        self.solar_to_battery = 0        
        self.battery_to_electrolyzer = 0
      #  self.electrolyzer_to_H2_out = 0
      #  self.electrolyzer_to_H2storage = 0        
      #  self.H2storage_to_H2_out = 0

class SolarFuelEnvironment(object):
    def __init__(self):
        
        self.T = lenT               # episode duration
        self.solar_PV_cost = 400     # unit price for solar PV in dollars/kwh 
        self.battery_cost = 20     # unit cost for battery in dollars/kwh
        self.charging_unit_cost = 10
        self.discharging_unit_cost = 10
        self.curtail_unit_cost = 20   # power wasted as curtail
        self.H2_demand = 1150  # MT  assume it's constant H2 out demand, but this scale is per day
        self.battery_storage_capacity = 2000  # kw  this scale is like there is no upper limit, can set even higher to imitate that ONE DAY OF STORAGE IS GOOD
        
        # self.H2storage_cost = 30     # H2 storage cost
        self.electrolyzer_cost = 1000  # /kw H2  ?
        self.H2_price = 2000  # /kw H2  ?
        self.electrolyzer_efficiency = 0.5  # /kw H2  ?
        # self.H2_storage_capacity = 2000 #  
        self.penalty_unit_cost = 2000  # penalty if not meeting demand, assumption now, higest
        
        self.reset()

    def reset(self): #, demand_history_len = 4):
        self.t = 0

    def solar_PV(self,  t): # 
        return whole_year_supply_df['volume'].iloc[t]
    
    def initial_state(self):
        return State(T=self.T, solar_in=0, battery_level=235, t=0) #, list(self.demand_history))

    def step(self, state, action):
        
        # calculating the reward (profit)
        # sales by the H2 sale
        

        # calculating the next state. REVIEW THIS. THIS IS VERY STRANGE!
    
    # BASELINE AND DISCRETE ACTIONS!
        self.solar_to_electrolyzer = action.solar_to_electrolyzer*min(self.H2_demand/24, state.solar_in)
        self.solar_to_battery = action.solar_to_battery*(state.solar_in - self.solar_to_electrolyzer)
        self.solar_to_curtail = action.solar_to_curtail*(state.solar_in - self.solar_to_electrolyzer - self.solar_to_battery)
        if self.solar_to_electrolyzer < self.H2_demand/24:
            self.battery_to_electrolyzer = action.battery_to_electrolyzer*(self.H2_demand/24 - self.solar_to_electrolyzer)    
        else:
            self.battery_to_electrolyzer = 0
        

        # #CONTINUOUS ACTIONS!
        # self.solar_to_electrolyzer = action.solar_to_electrolyzer
        # self.solar_to_battery = action.solar_to_battery
        # self.solar_to_curtail = (state.solar_in - self.solar_to_battery - self.solar_to_electrolyzer) #action.solar_to_curtail
        # self.battery_to_electrolyzer = action.battery_to_electrolyzer
       
        # the power to H2 converted
        # next hour

        next_state = state #State(T=self.T, solar_in=state.solar_in, battery_level=state.battery_level, t=self.t)     
        next_state.solar_in = self.solar_PV(self.t)  # input solar, just read from the dataframe
        if next_state.solar_in < 0:
            print(next_state.solar_in)
        next_state.battery_level = state.battery_level + self.solar_to_battery - self.battery_to_electrolyzer

        #COST BASED ON VOLUME (MISSING SOLAR TO ELECTROLIZER COST)
        revenue = (self.solar_to_electrolyzer + self.battery_to_electrolyzer) * self.H2_price
        # solar_prod_cost = self.solar_PV_cost * state.solar_in  # solar cost,don't know should include or not,ignore first
        # electrolyzer_cost = (action.solar_to_electrolyzer+action.battery_to_electrolyzer)*self.electrolyzer_cost
        battery_cost = abs(state.battery_level*self.battery_cost) #ADD INSTALATION COST
        # battery_cost = self.battery_cost
        charging_cost = self.solar_to_battery*self.charging_unit_cost
        discharging_cost = self.battery_to_electrolyzer*self.discharging_unit_cost
        curtail_cost = abs(self.solar_to_curtail)*self.curtail_unit_cost
        penalty_cost = - self.penalty_unit_cost * (min(self.solar_to_electrolyzer + self.battery_to_electrolyzer - self.H2_demand/24,0))  # needs to check

        # #COST BASED ON FLAT FEE (MISSING SOLAR TO ELECTROLIZER COST)
        # revenue = (self.solar_to_electrolyzer + self.battery_to_electrolyzer) * self.H2_price
        # solar_prod_cost = self.solar_PV_cost * state.solar_in  # solar cost,don't know should include or not,ignore first
        # # electrolyzer_cost = (action.solar_to_electrolyzer+action.battery_to_electrolyzer)*self.electrolyzer_cost
        # battery_cost = self.battery_cost 
        # charging_cost = action.solar_to_battery*self.charging_unit_cost
        # discharging_cost = action.battery_to_electrolyzer*self.discharging_unit_cost
        # curtail_cost = action.solar_to_curtail*self.curtail_unit_cost
        # penalty_cost = - self.penalty_unit_cost * (min(self.solar_to_electrolyzer\
        #                  + self.battery_to_electrolyzer - self.H2_demand/              24,0))  # needs to check

        reward = revenue - battery_cost - charging_cost - discharging_cost - curtail_cost - penalty_cost
        
        penalty_neg_battery_level = 0
        penalty_high_battery_level = 0
        penalty_amount_energy = 0
        penalty_excess_production = 0
        penalty_energy_electrolyze = 0
        penalty_energy_battery = 0
        penalty_energy_curtail = 0
        
        if next_state.battery_level < 0:
            penalty_neg_battery_level = 10 + abs(next_state.battery_level)
            reward = reward - penalty_neg_battery_level**2
            if penalty_neg_battery_level < 0:
                raise Exception("The penalty for negative battery is negative! This is wrong!")
        elif next_state.battery_level > self.battery_storage_capacity:
            penalty_high_battery_level = 10 + abs(self.battery_storage_capacity - next_state.battery_level)
            reward = reward - penalty_high_battery_level**2
            if penalty_high_battery_level < 0:
                raise Exception("The penalty for high battery is negative! This is wrong!")
            
        #PENALTIES FOR CONTINUOS ACTIONS!    
        if (self.solar_to_electrolyzer + self.solar_to_battery + self.solar_to_curtail) != state.solar_in : #SHOULD BE EQUAL!
            penalty_amount_energy = 10 + abs(state.solar_in - self.solar_to_electrolyzer - self.solar_to_battery - self.solar_to_curtail)
            if penalty_amount_energy < 0:
                raise Exception("The penalty for excess energy amount is negative! This is wrong!")
            reward = reward - penalty_amount_energy**2
            
        if (self.solar_to_electrolyzer + self.battery_to_electrolyzer)  > self.H2_demand : #THINK ABOUT ADDING H2 TANK
            penalty_excess_production = 10 + abs(self.H2_demand - self.solar_to_electrolyzer - self.battery_to_electrolyzer)
            if penalty_excess_production < 0:
                raise Exception("The penalty for excess production actions is negative! This is wrong!")
            reward = reward - penalty_excess_production**2
        
        if  (self.solar_to_curtail > state.solar_in) or (self.solar_to_curtail < 0):
            penalty_energy_curtail = 10 + abs(self.solar_to_curtail)
            reward = reward - penalty_energy_curtail**2
        
        if  (self.solar_to_electrolyzer > state.solar_in) or (self.solar_to_electrolyzer < 0):
            penalty_energy_electrolyze = 10 + abs(self.solar_to_electrolyzer)
            reward = reward - penalty_energy_electrolyze**2
        
        if  (self.solar_to_battery > state.solar_in) or (self.solar_to_battery < 0):
            penalty_energy_battery = 10 + abs(self.solar_to_battery)
            reward = reward - penalty_energy_battery**2

         
        # print(f'Penalty Amount of Energy:{penalty_amount_energy**2}, Penalty Excess Energy:{penalty_excess_production**2}, Penalty Negative Battery:{penalty_neg_battery_level**2}, Penalty High Battery:{penalty_high_battery_level**2}')
        # print(f'To Curtail Penalty:{penalty_energy_curtail**2}, To Electrolyzer Penalty:{penalty_energy_electrolyze**2}, To Battery Penalty:{penalty_energy_battery**2}')

        feedback = {0:self.solar_to_battery,1: self.solar_to_electrolyzer,2: self.solar_to_curtail,3: self.battery_to_electrolyzer}  
   
        # negative_energy_penalty = 0  
          
        # if self.solar_to_electrolyzer < 0:
        #     negative_energy_penalty = negative_energy_penalty + abs(self.solar_to_electrolyzer)**2
            
        # if self.solar_to_battery < 0:
        #     negative_energy_penalty = negative_energy_penalty + abs(self.solar_to_battery)**2
            
        # if self.solar_to_curtail < 0:
        #     negative_energy_penalty = negative_energy_penalty + abs(self.solar_to_curtail)**2
            
        # if self.battery_to_electrolyzer < 0:
        #     negative_energy_penalty = negative_energy_penalty + abs(self.battery_to_electrolyzer)**2
            
        # if negative_energy_penalty < 0:
        #     raise Exception("The penalty for negative actions is negative! This is wrong!")
        
        # reward = reward - negative_energy_penalty**0.5
            
        self.t += 1
        
        # print(f'Solar In:{next_state.solar_in}, Battery level:{next_state.battery_level}, Solar to Elec:{self.solar_to_electrolyzer}, Solar to Bat:{self.solar_to_battery}, Solar to Curtail:{self.solar_to_curtail}')
        # print(f'Reward:{reward}, Revenue:{revenue}, Battery cost:{battery_cost}, Charging cost:{charging_cost}, Discharging Cost:{discharging_cost}, Curtail cost:{curtail_cost}, Penalty Cost:{penalty_cost}')

        return next_state, reward, self.t == (self.T - 1), feedback
    
  # gym environment wrapper for the 
class SimpleSolarFuelOpt(gym.Env):
    def __init__(self):
        # 
        self.action_space = spaces.MultiDiscrete(np.array([2,2,2,2]))  #  4 different actions, should be continuous space
        # self.action_space = spaces.Box(low=-1, high=1, shape=(3,), dtype=np.float32)
        self.observation_space = spaces.Box(low=np.array([-200.0, -2000.0]), high=np.array([200.0, 2000.0]), dtype=np.float32)  # only two states

        self.reset()

    def reset(self):
        self.sfo_chain = SolarFuelEnvironment()
        self.state = self.sfo_chain.initial_state()
        return self.state.to_array()

    def step(self, action): 
        action_obj = Action()

        action_obj.solar_to_battery = action[0]
        action_obj.solar_to_curtail = action[1]
        action_obj.battery_to_electrolyzer = action[2]
        action_obj.solar_to_electrolyzer = action[3]
        self.state, reward, done, feedback = self.sfo_chain.step(self.state, action_obj)
        return self.state.to_array(), reward, done, feedback

class ProgressBarCallback(BaseCallback):
    """
    :param pbar: (tqdm.pbar) Progress bar object
    """
    def __init__(self, pbar):
        super(ProgressBarCallback, self).__init__()
        self._pbar = pbar

    def _on_step(self):
        # Update the progress bar:
        self._pbar.n = self.num_timesteps
        self._pbar.update(0)

# this callback uses the 'with' block, allowing for correct initialisation and destruction
class ProgressBarManager(object):
    def __init__(self, total_timesteps): # init object with total timesteps
        self.pbar = None
        self.total_timesteps = total_timesteps
        
    def __enter__(self): # create the progress bar and callback, return the callback
        self.pbar = tqdm(total=self.total_timesteps)
            
        return ProgressBarCallback(self.pbar)

    def __exit__(self, exc_type, exc_val, exc_tb): # close the callback
        self.pbar.n = self.total_timesteps
        self.pbar.update(0)
        self.pbar.close()
        
 #define some functions to visualize the episodes and save transitions

#% Visualization function 
def prepare_metric_plot(plots_n, n, ylabel):
    plt.subplot(plots_n, 1, n)
    plt.ylabel(ylabel)
    plt.tick_params(axis='x', which='both', bottom=True, top=True, labelbottom=False)

# visualizing one episode - stock levels, production and reorderign actions, and rewards
def visualize_transitions(transitions, partial, results_path):
    state_trace, action_trace, reward_trace, feedback = (transitions[:,1:3], transitions[:,3:7], transitions[:,7], transitions[:,7:])
    plots_n = 8
    times_steps = range(len(reward_trace))
    mpl.rcParams['lines.linewidth'] = 2    
    print(f"Return is {sum(reward_trace)}")

    fig = plt.figure(figsize=(15, 30))
    # state plots
    prepare_metric_plot(plots_n, 1, "Input level,\n Solar PV")
    # plt.plot(range(lenT), list(map(lambda s: s.solar_in, state_trace)), c='yellow', alpha=0.5)
    plt.plot(times_steps, state_trace[:,0], c='yellow', alpha=0.5)
    
 
    prepare_metric_plot(plots_n, 2, "Battery level")
    # plt.plot(range(lenT), list(map(lambda s: s.battery_level, state_trace)), c='purple', alpha=0.5)
    plt.plot(times_steps, state_trace[:,1], c='yellow', alpha=0.5)

 
  #  prepare_metric_plot(plots_n, 3, "H2 generated")
  #  plt.plot(range(env.T), list(map(lambda s: s.electrolyzer_converted_toH2, state_trace)), c='orange', alpha=0.5)
    
 
  #  prepare_metric_plot(plots_n, 4, "Demand,\n H2")
  #  plt.plot(range(env.T), list(map(lambda s: s.H2_out, state_trace)), c='red', alpha=0.5)
              
    prepare_metric_plot(plots_n, 3, "Curtail,\n Solar")
    plt.plot(times_steps, feedback[:,2], c='green', alpha=0.5)
    
    prepare_metric_plot(plots_n, 4, "to electrolyzer,\n Solar")
    plt.plot(times_steps, feedback[:,1], c='cyan', alpha=0.5)
    
    prepare_metric_plot(plots_n, 5, "to battery,\n Solar")
    plt.plot(times_steps, feedback[:,0], c='magenta', alpha=0.5)
    
    prepare_metric_plot(plots_n, 6, "to electrolyzer,\n Battery")
    plt.plot(times_steps, feedback[:,3], c='purple', alpha=0.5)
 
    prepare_metric_plot(plots_n, 7, "Profit")
    plt.plot(times_steps, reward_trace, c='red', alpha=0.9, linewidth=2)

    plt.subplot(plots_n, 1, 8)
    plt.ylabel("Cumulative\nprofit")
   # plt.ylim(0, 10000)
    plt.plot(times_steps, np.cumsum(reward_trace), c='red', alpha=0.9, linewidth=2)
    plt.xlabel("Time step")
    
    if partial: 
        plt.savefig(f'{results_path}/result_plt_partial.png', dpi=300)
    else:
        plt.savefig(f'{results_path}/result_plt_full.png', dpi=300)

# data frame generation function
def save_transitions(transitions, results_path):
    state_trace, action_trace, reward_trace, feedback = (transitions[:,1:3], transitions[:,3:7], transitions[:,7], transitions[:,7:])

    solar_in=list(state_trace[:,0])
    battery_level = list(state_trace[:,1])
    # converted_H2= list(map(lambda s: s.electrolyzer_converted_toH2, state_trace))
    # demand_state=list(map(lambda s: s.H2_out, state_trace)) 
    H2_demand = 1100/24
    solar_to_curtail=list(feedback[:,2])
    solar_to_electrolyzer=list(feedback[:,1])
    solar_to_battery=list(feedback[:,0])
    battery_to_electrolyzer=list(feedback[:,3])
    profit=reward_trace
    time= range(lenT)
    result_df = pd.DataFrame(
    {'time': time,
     'solar_in': solar_in,
     'battery_level': battery_level,
    #  'converted_H2': converted_H2,
     'H2_demand':H2_demand,
     'solar_to_curtail': solar_to_curtail,
     'solar_to_electrolyzer': solar_to_electrolyzer,
     'solar_to_battery': solar_to_battery,
     'battery_to_electrolyzer': battery_to_electrolyzer,
     'profit': profit     
    })
    result_df.to_csv(f'{results_path}/test_results.csv')
   
#Optimizing the Policy Using Reinforcement Learning / RLlib     
def rl_model_training(experiment_name, log_path, results_path, steps_scale_factor, eval_freq=50000, progress_bar=False):
    print('Started')
    env1 = SimpleSolarFuelOpt()
    # env1 = Monitor(env1)
    check_env(env1)
    env = SubprocVecEnv([lambda: env1])
    env = VecNormalize(env, norm_obs=True, norm_reward=True, clip_obs=10)
    env = VecMonitor(env)
    model = PPO("MlpPolicy", env, verbose=0, learning_rate=1e-4, batch_size=128, tensorboard_log=results_path, device='cuda')
    timesteps = lenT*steps_scale_factor
    print(f'The total timesteps is {timesteps}')
    print(f'Evaluating the model every {eval_freq} steps')

    # eval_callback = EvalCallback(env, best_model_save_path=log_path,
    #                             log_path=log_path, eval_freq=eval_freq, #timesteps/2000,
    #                             deterministic=True, render=False)
    print('Learning started')
    if progress_bar:
        with ProgressBarManager(timesteps) as callback_pg:
            model.learn(total_timesteps=timesteps, callback=[callback_pg])#, eval_callback])
    else:
        model.learn(total_timesteps=timesteps, tb_log_name=experiment_name, log_interval=10) #, callback=[eval_callback])

    model.save(f'{results_path}/model')
    return model
    
def rl_model_testing(results_path, model=None):
    
    env1 = SimpleSolarFuelOpt()
    check_env(env1)
    env1 = Monitor(env1)
    env = SubprocVecEnv([lambda: env1])
    model = PPO("MlpPolicy", env, verbose=False)
    obs = env.reset()
    
    if model is not None:
        model = PPO.load(f'{results_path}/model')  # get from the saved model
        
    transitions_init = np.empty([lenT, 12])
    for i in range(lenT):  # actually only 42 steps
        action, states = model.predict(obs, deterministic=True)
        print("action:",action)
        obs, rewards, dones, feedback = env.step(action)
        print("obs:",obs)
        print("rewards:",rewards)
        # import ipdb; ipdb.set_trace()
        transitions_init[i,:] = np.column_stack([states, obs, action, rewards, feedback[0][0], feedback[0][1], feedback[0][2], feedback[0][3]])

    visualize_transitions(transitions = np.array(transitions_init), results_path=results_path, partial=False)
    visualize_transitions(transitions = np.array(transitions_init[:50,]), results_path=results_path, partial=True)
    result_df=save_transitions(transitions=np.array(transitions_init), results_path=results_path)

    return result_df

if __name__=="__main__":
    experiment_name, eval_freq, steps_scale_factor, num_of_months = parse_parameters()
    
    data_path = "/glb/hou/gf.siti/data/rl_sfo/luiz_code/solar_fuel_ReinforcementLearning/data/solar_profile_hourlyV2.csv"
    path = f"/glb/hou/gf.siti/data/rl_sfo/luiz_code"
    results_path = f"{path}/results/{experiment_name}"
    log_path= f"{results_path}/callbacks"
    
    print(f"Creating folder required folders")
    os.makedirs(f"{results_path}", exist_ok=True)
    os.makedirs(f"{log_path}", exist_ok=True)
    
    whole_year_supply_df, lenT = load_solar_profile(data_path=data_path)
    
    model = rl_model_training(log_path=log_path,
                              results_path=results_path,
                              eval_freq=eval_freq,
                              steps_scale_factor=steps_scale_factor,
                              progress_bar=False,
                              experiment_name=experiment_name)
                    
    result_df = rl_model_testing(results_path=results_path, model=model)