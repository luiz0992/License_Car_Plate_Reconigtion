"""
Created on Mon Feb 28 13:56:05 2022

Solar fuel optimization using Reinforcement learning

@author: Luiz F. G. dos Santos & Tina Zhao
"""
import os
import json
import shutil
from datetime import datetime
import gym
import numpy as np
import pandas as pd
import torch
import yaml
import math

from dateutil.relativedelta import relativedelta
from gym import spaces
from stable_baselines3 import PPO
from stable_baselines3.common.vec_env import SubprocVecEnv, VecNormalize
from stable_baselines3.common.env_checker import check_env
from stable_baselines3.common.monitor import Monitor
from stable_baselines3.common.callbacks import EvalCallback, CheckpointCallback

from src.data.dataloader import load_solar_profile
from src.utilities import (calculate_hourly_demand,
                           normalize_val,
                           denormalize_val,
                           set_seed,
                           parse_parameters,
                           parse_yaml_props,
                           calculate_hourly_demand)
from src.visualization.visualize import visualize_transitions
from src.global_variables import *

GLOBALCOUNTER=1
torch.set_num_threads(16)
set_seed()
#Set up the environment
# define the environment
class State(object):
    """_summary_

    Args:
        object (_type_): _description_
    """

    def __init__(self, t_total=744, solar_in=0, battery_level=5000, time=0):

       # at solar
        self.solar_in = solar_in  #0 solar input level
        self.battery_level = battery_level  #235 stock level

        self.solar_in = normalize_val(self.solar_in, MIN_SOLAR_IN, MAX_SOLAR_IN)
        self.battery_level = normalize_val(self.battery_level,
                                           MIN_BATTERY_STORAGE_CAPACITY,
                                           MAX_BATTERY_STORAGE_CAPACITY)

        self.t_total = t_total
        self.time = time

    def to_array(self):
        """_summary_

        Returns:
            _type_: _description_
        """
        return np.concatenate(([self.solar_in], [self.battery_level]), dtype=np.float32)

class Action(object):
    """_summary_

    Args:
        object (_type_): _description_
    """
    def __init__(self):

        self.solar_to_electrolyzer = 0
        self.solar_to_curtail = 0
        self.solar_to_battery = 0
        self.battery_to_electrolyzer = 0

class SolarFuelEnvironment(object):
    """_summary_

    Args:
        object (_type_): _description_
    """
    def __init__(self,
                 len_t,
                 whole_year_supply_df,
                 curtail_unit_cost,
                 h2_demand,
                 battery_storage_capacity,
                 electrolyzer_cost,
                 h2_price,
                 penalty_unit_cost):
        '''
        count     730.000000
        mean     1420.709119 Twh
        std      1983.723497
        min         0.000000
        25%         0.000000
        50%         0.000000
        75%      3357.047813
        max      6401.068290
        Name: TMY P90, dtype: float64
        '''

        self.t_total = len_t # episode duration
        self.whole_year_supply_df = whole_year_supply_df
        self.hourly_demand = h2_demand
        self.battery_unit_cost = 0
        self.charging_unit_cost = 0
        self.discharging_unit_cost = 0
        self.curtail_unit_cost = curtail_unit_cost 
        self.h2_demand = None
        self.battery_storage_capacity = battery_storage_capacity
        self.electrolyzer_cost = electrolyzer_cost 
        self.h2_price = h2_price
        self.penalty_unit_cost = penalty_unit_cost
        self.reward_list=[]
        self.batery_list=[]
        self.reset()

    def reset(self):
        """_summary_

        Args:
            self (_type_): _description_
            demand_history_len (int, optional): _description_. Defaults to 4.
        """
        self.time = 0

    def solar_pv(self,  time):
        """_summary_

        Args:
            time (_type_): _description_

        Returns:
            _type_: _description_
        """
        return self.whole_year_supply_df[time]

    def load_hourly_demand(self,  time):
        """_summary_

        Args:
            time (_type_): _description_

        Returns:
            _type_: _description_
        """
        return self.hourly_demand[time]

    def initial_state(self):
        """_summary_

        Returns:
            _type_: _description_
        """
        return State(t_total=self.t_total, solar_in=0, battery_level=5000, time=0)

    def step(self, state, action):
        """_summary_

        Args:
            state (_type_): _description_
            action (_type_): _description_

        Returns:
            _type_: _description_
        """

        state.solar_in = denormalize_val(state.solar_in,
                                         MIN_SOLAR_IN,
                                         MAX_SOLAR_IN)
        state.battery_level = denormalize_val(state.battery_level,
                                           MIN_BATTERY_STORAGE_CAPACITY,
                                           MAX_BATTERY_STORAGE_CAPACITY)

        self.h2_demand = self.load_hourly_demand(self.time)
        # self.h2_demand = 11.15 if state.solar_in == 0 else 200
        # print(f"The demand is {self.h2_demand}")
        revenue = (action.solar_to_electrolyzer + action.battery_to_electrolyzer) * self.h2_price
        # print(f"Revenue: {revenue}")
        # battery_reward = action.solar_to_battery * self.h2_price/5
        battery_reward = 0

        action.solar_to_curtail = (state.solar_in -
                                   action.solar_to_battery -
                                   action.solar_to_electrolyzer)

        battery_cost = abs(state.battery_level)*self.battery_unit_cost
        charging_cost = abs(action.solar_to_battery)*self.charging_unit_cost
        discharging_cost = abs(action.battery_to_electrolyzer)*self.discharging_unit_cost
        electrolyzer_cost = abs(action.solar_to_electrolyzer +
                            action.battery_to_electrolyzer)*self.electrolyzer_cost
        curtail_cost = abs(action.solar_to_curtail)*self.curtail_unit_cost

        penalty_under_production = self.penalty_unit_cost*abs(min(action.solar_to_electrolyzer +\
                                                                  action.battery_to_electrolyzer -\
                                                                  self.h2_demand*0.75,0))

        reward = revenue +\
                 battery_reward -\
                 battery_cost -\
                 charging_cost -\
                 discharging_cost -\
                 electrolyzer_cost -\
                 penalty_under_production -\
                 curtail_cost

        reward_adjusted = reward - battery_reward + penalty_under_production + curtail_cost

        # next hour
        next_state = State(t_total=self.t_total, time=self.time)
        next_state.solar_in = self.solar_pv(self.time)  # input solar, just read from the dataframe
        next_state.battery_level = state.battery_level + \
                                   action.solar_to_battery - \
                                   action.battery_to_electrolyzer

        next_state.solar_in = normalize_val(next_state.solar_in,
                                              MIN_SOLAR_IN,
                                              MAX_SOLAR_IN)
        next_state.battery_level = normalize_val(next_state.battery_level,
                                                   MIN_BATTERY_STORAGE_CAPACITY,
                                                   MAX_BATTERY_STORAGE_CAPACITY)
        action.solar_to_curtail = normalize_val(action.solar_to_curtail,
                                                MIN_SOLAR_IN,
                                                MAX_SOLAR_IN)

        # self.batery_list.append(next_state.battery_level)
        penalty = 0
        penalty_negative_battery_level = 0
        penalty_excess_battery_level = 0
        # penalty_bat_to_elec = 0
        penalty_amount_energy = 0
        penalty_excess_production = 0
        norm_factor = 1e5
        ##### PENALTIES #####
        if not 0 <= next_state.battery_level <= 1:
            if next_state.battery_level < 0:
                penalty_negative_battery_level=(0.05*abs(next_state.battery_level))**0.5
                penalty += penalty_negative_battery_level
            else:
                penalty_excess_battery_level = (0.05*(next_state.battery_level - 1))**0.5
                penalty += penalty_excess_battery_level

        if action.solar_to_curtail < 0:
            penalty_amount_energy = (0.05*abs(action.solar_to_curtail))**0.5
            penalty += penalty_amount_energy

        # if self.battery_to_electrolyzer > state.battery_level:
        #     penalty_bat_to_elec = (self.counter*(1 + abs(self.battery_to_electrolyzer -
        #                                     state.battery_level)))
        #     penalty += penalty_bat_to_elec

        # #THINK ABOUT ADDING H2 TANK
        # if (self.solar_to_electrolyzer + self.battery_to_electrolyzer) > self.h2_demand/24:
        #     penalty_excess_production = (1 + abs((self.h2_demand/24) -
        #                                           self.solar_to_electrolyzer -
        #                                           self.battery_to_electrolyzer))/1e4

        if (action.solar_to_electrolyzer + action.battery_to_electrolyzer) > self.h2_demand*1.25:
            penalty_excess_production = (1 + abs(self.h2_demand*1.25 -
                                                  action.solar_to_electrolyzer -
                                                  action.battery_to_electrolyzer))/1e4
            penalty += penalty_excess_production

        # global GLOBALCOUNTER

        # if not 0 <= state.battery_level <= 1:
        #     if next_state.battery_level < 0:
        #         penalty_negative_battery_level=(GLOBALCOUNTER/norm_factor)*(0.05*abs(state.battery_level))**0.5
        #         penalty += penalty_negative_battery_level
        #     else:
        #         penalty_excess_battery_level = (GLOBALCOUNTER/norm_factor)*(0.05*(state.battery_level - 1))**0.5
        #         penalty += penalty_excess_battery_level

        # if action.solar_to_curtail < 0:
        #     penalty_amount_energy = (GLOBALCOUNTER/norm_factor)*(0.05*abs(action.solar_to_curtail))**0.5
        #     penalty += penalty_amount_energy

        # if (action.solar_to_electrolyzer + action.battery_to_electrolyzer) > (self.h2_demand/24)*1.25:
        #     penalty_excess_production = (GLOBALCOUNTER/norm_factor)*(0.05*abs((self.h2_demand/24)*1.25 -
        #                                                                 action.solar_to_electrolyzer -
        #                                                                 action.battery_to_electrolyzer))**0.5
            # penalty_excess_production = 0
            # penalty += penalty_excess_production

        # GLOBALCOUNTER += 1

        penalties = {"penalty_negative_battery_level": penalty_negative_battery_level,
                     "penalty_excess_battery_level": penalty_excess_battery_level,
                     "penalty_excess_production":penalty_excess_production,
                     "penalty_under_production":penalty_under_production,
                     "penalty_amount_energy":penalty_amount_energy,
                     "curtail_cost": curtail_cost
                     }
        # print(penalties)

        # print(reward)
        reward=reward/1e6
        # print(reward)
        # print("")
        reward = reward - penalty
        
        # self.reward_list.append(reward)

        # print(f"Reward: {reward}")
        
        costs = {"battery_cost": battery_cost,
                "charging_cost": charging_cost,
                "discharging_cost": discharging_cost,
                "electrolyzer_cost": electrolyzer_cost,
                "penalty_under_production": penalty_under_production,
                "curtail_cost": curtail_cost}

        # print(costs)
        # print(f"Reward without penalties: {reward}")

        action.solar_to_curtail = denormalize_val(action.solar_to_curtail, MIN_SOLAR_IN, MAX_SOLAR_IN)

        feedback = {"solar_in": state.solar_in,
                    "battery_level": next_state.battery_level,
                    "solar_to_battery": action.solar_to_battery,
                    "solar_to_electrolyzer": action.solar_to_electrolyzer,
                    "solar_to_curtail": action.solar_to_curtail,
                    "battery_to_electrolyzer": action.battery_to_electrolyzer,
                    "reward_adjusted": reward_adjusted,
                    "reward": reward}
        # print("")
        # print(feedback)
        # print(penalties)
        # print(costs)
        # print("")

        # print({k:v/1e5 for (k,v) in penalties.items() if v > 100})
        # print(penalties)
        # if self.time == self.t_total-1:
        #     ave=pd.DataFrame(self.reward_list)
        #     print(ave.describe())
        #     self.reward_list=[]
        ##### PRINTING DEBUG INFO #####

        # tol = 1e-2
        # if next_state.battery_level > 1+tol:
        #     print("Battery greater than permited capacity")
        #     print("")
        # elif next_state.battery_level < 0-tol:
        #     print("Battery less than permited capacity")
        #     print("")

        # if self.solar_to_curtail < 0-tol:
        #     print("Failed with solar curtailment")
        #     print("")
        # if (impossible_action == True) and (GLOBALCOUNTER > 1e3):
        #     done = True
        # else:
        #     if self.time == (self.t_total - 1):
        #         done=True
        #     else:
        #         done=False

        self.time += 1

        return next_state, reward, self.time == (self.t_total - 1), feedback, penalties

  # gym environment wrapper for the
class SimpleSolarFuelOpt(gym.Env):
    """_summary_

    Args:
        gym (_type_): _description_
    """
    def __init__(self,
                 len_t,
                 whole_year_supply_df,
                 curtail_unit_cost,
                 h2_demand,
                 battery_storage_capacity,
                 electrolyzer_cost,
                 h2_price,
                 penalty_unit_cost):

        self.action_space = spaces.Box(low=-1,
                                       high=1,
                                       shape=(3,),
                                       dtype=np.float32)
        self.observation_space = spaces.Box(low=np.array([0,-1e10], dtype=np.float32),
                                            high=np.array([MAX_SOLAR_IN,+1e10], dtype=np.float32),
                                            shape=(2,),
                                            dtype=np.float32)  # only two states
        self.len_t = len_t
        self.whole_year_supply_df = whole_year_supply_df
        self.curtail_unit_cost = curtail_unit_cost
        self.h2_demand = h2_demand
        self.battery_storage_capacity = battery_storage_capacity
        self.electrolyzer_cost = electrolyzer_cost
        self.h2_price = h2_price
        self.penalty_unit_cost = penalty_unit_cost
        self.reset()

    def reset(self):
        self.sfo_chain=SolarFuelEnvironment(len_t=self.len_t,
                                            whole_year_supply_df=self.whole_year_supply_df,
                                            curtail_unit_cost=self.curtail_unit_cost,
                                            h2_demand=self.h2_demand,
                                            battery_storage_capacity=self.battery_storage_capacity,
                                            electrolyzer_cost=self.electrolyzer_cost,
                                            h2_price=self.h2_price,
                                            penalty_unit_cost=self.penalty_unit_cost)
        self.state = self.sfo_chain.initial_state()
        return self.state.to_array()

    def step(self, action:object):
        action_obj = Action()
        action_obj.solar_to_battery = (action[0]+1)*MAX_SOLAR_IN/2
        action_obj.solar_to_electrolyzer = (action[1]+1)*MAX_SOLAR_IN/2
        action_obj.battery_to_electrolyzer = (action[2]+1)*MAX_BATTERY_STORAGE_CAPACITY/2
        
        self.state, reward, done, feedback, penalties = self.sfo_chain.step(self.state, action_obj)

        return self.state.to_array(), reward, done, {0:feedback, 1:penalties}

# data frame generation function
def save_transitions(transitions,
                     len_t,
                     results_path):
    """_summary_

    Args:
        transitions (_type_): _description_
        len_t (_type_): _description_
        results_path (_type_): _description_

    Returns:
        _type_: _description_
    """
    state_trace, _action_trace, reward_trace, feedback, reward_adjusted = (transitions[:,1:3],
                                                                           transitions[:,3:6],
                                                                           transitions[:,6]*1e10,
                                                                           transitions[:,7:-1],
                                                                           transitions[:,-1])

    state_trace[:,0] = denormalize_val(state_trace[:,0],
                                      MIN_SOLAR_IN,
                                      MAX_SOLAR_IN)
    state_trace[:,1] = denormalize_val(state_trace[:,1],
                                      MIN_BATTERY_STORAGE_CAPACITY,
                                      MAX_BATTERY_STORAGE_CAPACITY)

    solar_in=list(state_trace[:,0])
    battery_level = list(state_trace[:,1])
    h2_demand = 62402.63/24
    solar_to_curtail=list(feedback[:,2])
    solar_to_electrolyzer=list(feedback[:,1])
    solar_to_battery=list(feedback[:,0])
    battery_to_electrolyzer=list(feedback[:,3])
    profit=reward_trace
    time= range(len_t)
    result_df = pd.DataFrame(
    {'time': time,
     'solar_in': solar_in,
     'battery_level': battery_level,
     'h2_demand':h2_demand,
     'solar_to_curtail': solar_to_curtail,
     'solar_to_electrolyzer': solar_to_electrolyzer,
     'solar_to_battery': solar_to_battery,
     'battery_to_electrolyzer': battery_to_electrolyzer,
     'profit': profit,
     'profit_adjusted': reward_adjusted
    })
    result_df.to_csv(f'{results_path}/test_results.csv')
    return result_df

#Optimizing the Policy Using Reinforcement Learning / RLlib
def rl_model_training(experiment_name,
                      results_path,
                      steps_scale_factor,
                      len_t,
                      whole_year_supply_df,
                      eval_freq,
                      curtail_unit_cost,
                      h2_demand,
                      battery_storage_capacity,
                      electrolyzer_cost,
                      h2_price,
                      penalty_unit_cost):
    """_summary_

    Args:
        experiment_name (_type_): _description_
        log_path (_type_): _description_
        results_path (_type_): _description_
        steps_scale_factor (_type_): _description_
        len_t (_type_): _description_
        whole_year_supply_df (_type_): _description_
        eval_freq (int, optional): _description_. Defaults to 50000.
        progress_bar (bool, optional): _description_. Defaults to False.

    Returns:
        _type_: _description_
    """
    print('Started')
    env = SimpleSolarFuelOpt(len_t=len_t,
                              whole_year_supply_df=whole_year_supply_df,
                              curtail_unit_cost=curtail_unit_cost,
                              h2_demand=h2_demand,
                              battery_storage_capacity=battery_storage_capacity,
                              electrolyzer_cost=electrolyzer_cost,
                              h2_price=h2_price,
                              penalty_unit_cost=penalty_unit_cost)
    env1 = Monitor(env)
    check_env(env1)
    env = SubprocVecEnv([lambda: env1])
    eval_callback = EvalCallback(env, best_model_save_path=f'{results_path}/best_model',
                                 log_path=f'{results_path}/logs', eval_freq=eval_freq,
                                 deterministic=True, render=False)
    checkpoint = CheckpointCallback(save_freq=100000,
                                    save_path=f'{results_path}/best_model',
                                    name_prefix='model_')
    model = PPO("MlpPolicy",
                env,
                verbose=0,
                learning_rate=1e-4,
                batch_size=32,
                gamma=0.999,
                tensorboard_log=results_path,
                device='cpu')
    timesteps = len_t * steps_scale_factor
    print(f'The total timesteps is {timesteps}')
    print(f'Evaluating the model every {eval_freq} steps')
    print('Learning started')
    model.learn(total_timesteps=timesteps, callback=[eval_callback, checkpoint])
    model.save(f'{results_path}/last_ep_model')
    return model

def rl_model_testing(results_path,
                     len_t,
                     whole_year_supply_df,
                     curtail_unit_cost,
                     h2_demand,
                     battery_storage_capacity,
                     electrolyzer_cost,
                     h2_price,
                     penalty_unit_cost,
                     save_results=True,
                     parcial_results=True,
                     model=None,
                     baseline_path=None):
    """_summary_

    Args:
        results_path (_type_): _description_
        len_t (_type_): _description_
        whole_year_supply_df (_type_): _description_
        model (_type_, optional): _description_. Defaults to None.

    Returns:
        _type_: _description_
    """
    solar_in_delay=[]
    battery_level=[]
    solar_in=[]
    rewards=[]
    solar_to_battery=[]
    solar_to_electrolyzer=[]
    solar_to_curtail=[]
    battery_to_electrolyzer=[]
    reward_adjusted=[]

    penalty_negative_battery_level=[]
    penalty_excess_battery_level=[]
    penalty_excess_production=[]
    penalty_under_production=[]
    penalty_amount_energy=[]
    curtail_cost=[]

    env = SimpleSolarFuelOpt(len_t=len_t,
                             whole_year_supply_df=whole_year_supply_df,
                             curtail_unit_cost=curtail_unit_cost,
                             h2_demand=h2_demand,
                             battery_storage_capacity=battery_storage_capacity,
                             electrolyzer_cost=electrolyzer_cost,
                             h2_price=h2_price,
                             penalty_unit_cost=penalty_unit_cost)

    obs = env.reset()
    baseline_profit = None
    if model is None:
        # model = PPO.load(f'/glb/hou/gf.siti/data/rl_sfo/luiz_code/results/August01_Stopping_Impossible_Actions_171833/best_model/best_model.zip')  # get from the saved model
        model = PPO.load(f'{results_path}/best_model/best_model.zip')  # get from the saved model

    for _ in range(len_t):  # actually only 42 steps
        action, _states = model.predict(obs, deterministic=True)
        obs, reward, _, info = env.step(action)

        feedback = info[0]
        penalties = info[1]

        solar_in.append(float(obs[0]))
        battery_level.append(obs[1])
        rewards.append(reward)
        solar_in_delay.append(feedback["solar_in"])
        solar_to_battery.append(feedback["solar_to_battery"])
        solar_to_electrolyzer.append(feedback["solar_to_electrolyzer"])
        solar_to_curtail.append(feedback["solar_to_curtail"])
        battery_to_electrolyzer.append(feedback["battery_to_electrolyzer"])
        reward_adjusted.append(feedback["reward_adjusted"])

        penalty_negative_battery_level.append(penalties["penalty_negative_battery_level"])
        penalty_excess_battery_level.append(penalties["penalty_excess_battery_level"])
        penalty_excess_production.append(penalties["penalty_excess_production"])
        penalty_under_production.append(penalties["penalty_under_production"])
        penalty_amount_energy.append(penalties["penalty_amount_energy"])
        curtail_cost.append(penalties["curtail_cost"])

    if baseline_path is not None:
        baseline_profit = pd.read_csv(baseline_path)['profit adjusted']
        baseline_profit = np.array(baseline_profit)


    visualize_transitions(solar_in=np.array(solar_in_delay,dtype=float),
                          battery_level=np.array(battery_level, dtype=float),
                          h2_demand=h2_demand,
                          rewards=rewards,
                          solar_to_battery=np.array(solar_to_battery),
                          solar_to_electrolyzer=np.array(solar_to_electrolyzer),
                          solar_to_curtail=np.array(solar_to_curtail),
                          battery_to_electrolyzer=np.array(battery_to_electrolyzer),
                          reward_adjusted=np.array(reward_adjusted),
                          penalty_negative_battery_level=np.array(penalty_negative_battery_level),
                          penalty_excess_battery_level=np.array(penalty_excess_battery_level),
                          penalty_excess_production=np.array(penalty_excess_production, dtype=float),
                          penalty_under_production=np.array(penalty_under_production, dtype=float)/1e10,
                          penalty_amount_energy=np.array(penalty_amount_energy),
                          curtail_cost=np.array(curtail_cost, dtype=float)/1e10,
                          results_path=f'{results_path}',
                          save_results=save_results,
                          partial=parcial_results,
                          baseline_profit=baseline_profit)

def save_config_details(args, results_path, experiment_name):
    """
    Given some final arguments, save them as a YAML config to make it easier to
    both see what was configured as well as easily re-run an experiment given some config.
    """
    filename = os.path.join(results_path, f'{experiment_name}_config.yaml')
    with open(filename, mode='w+') as outfile:
        yaml.dump(args, outfile, default_flow_style=False)
    print(f'Saved final YAML config details to {filename}')

def main():
    """_summary_
    """
    data_path = '/glb/hou/gf.siti/data/rl_sfo/luiz_code/'\
                'solar_fuel_ReinforcementLearning/data/'\
                'solar_profile_hourlyV2.csv'
    path = '/glb/hou/gf.siti/data/rl_sfo/luiz_code'
    local_run = True
    print("")
    parsed = parse_parameters()
    experiment_name = parsed[0]
    eval_freq = parsed[1]
    steps_scale_factor = parsed[2]
    initial_month_train = parsed[3]
    initial_month_test = parsed[4]
    quantity_of_months_train = parsed[5]
    quantity_of_months_test = parsed[6]
    curtail_unit_cost = parsed[7]
    h2_demand = parsed[8]
    battery_storage_capacity = parsed[9]
    electrolyzer_cost = parsed[10]
    h2_price = parsed[11]
    penalty_unit_cost = parsed[12]
    hyperparameters_optimization = parsed[13]
    args = parsed[14]

    if local_run:
        print('For local run, the code will load all default parameters')
    print("The training parameters are:")
    print(args)

    results_path = f'{path}/results/{experiment_name}'
    log_path= f'{results_path}/callbacks'

    print('Creating folder required folders')
    os.makedirs(f"{results_path}", exist_ok=True)
    os.makedirs(f"{log_path}", exist_ok=True)
    shutil.copyfile('/glb/hou/gf.siti/data/rl_sfo/luiz_code/'\
                    'solar_fuel_ReinforcementLearning/src/pipelines/'\
                    'solar_fuel_op_usingstablebl.py',
                    f"{results_path}/solar_fuel_op_usingstablebl.py")

    save_config_details(args, results_path, experiment_name)
    with open(f"{results_path}/config_json_{experiment_name}.txt", "w+") as file:
        json.dump(args, file, indent=2)

    whole_year_supply_train=load_solar_profile(data_path=data_path,
                                                  initial_month=initial_month_train,
                                                  number_of_months=quantity_of_months_train,
                                                  year="TMY P90")
    len_t_train=len(whole_year_supply_train)
    houry_demand_train = calculate_hourly_demand(whole_year_supply=whole_year_supply_train,
                                                 total_demand=h2_demand,
                                                 buffer_demand=10000)
    print(f'The total number of hours training is {len_t_train}')  # total number of hours trained

    model = rl_model_training(results_path=results_path,
                              eval_freq=eval_freq,
                              steps_scale_factor=steps_scale_factor,
                              experiment_name=experiment_name,
                              len_t=len_t_train,
                              whole_year_supply_df=whole_year_supply_train,
                              curtail_unit_cost =curtail_unit_cost,
                              h2_demand = houry_demand_train,
                              battery_storage_capacity = battery_storage_capacity,
                              electrolyzer_cost = electrolyzer_cost,
                              h2_price = h2_price,
                              penalty_unit_cost = penalty_unit_cost)

    whole_year_supply_test = load_solar_profile(data_path=data_path,
                                                   initial_month=initial_month_test,
                                                   number_of_months=quantity_of_months_test,
                                                   year="TMY P90")
    len_t_test=len(whole_year_supply_test)
    houry_demand_test = calculate_hourly_demand(whole_year_supply=whole_year_supply_test,
                                                total_demand=h2_demand,
                                                buffer_demand=10000)
    print(f'The total number of hours testing is {len_t_test}')  # total number of hours tested

    rl_model_testing(results_path=results_path,
                     len_t=len_t_test,
                     model=model,
                     whole_year_supply_df=whole_year_supply_test,
                     curtail_unit_cost =curtail_unit_cost,
                     h2_demand = houry_demand_test,
                     battery_storage_capacity = battery_storage_capacity,
                     electrolyzer_cost = electrolyzer_cost,
                     h2_price = h2_price,
                     penalty_unit_cost = penalty_unit_cost)

if __name__=="__main__":

    main()
    