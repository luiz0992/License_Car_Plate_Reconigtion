# -*- coding: utf-8 -*-
"""
Created on Mon May  3 09:38:58 2021

@author: Tina.T.Zhao
"""

import sys
print(sys.executable)

#%% get in the real demand data
from datetime import datetime, timedelta, date
import pandas as pd
import numpy as np
import math
#from .utils.path_to_dataframe import path_to_pandas, pandas_to_local_or_blob


def datestr2datetime(datestr: str, format="%Y-%m-%d"):
    """
        convert datestr in %Y-%m-%d to datetime
    """
    return datetime.strptime(datestr, format)


def add_to_trainschedule(number_train, last_day, month_toadd, list_toadd):
    j = number_train - 1
    while (j >= 0):
        firsthalf_day_index = last_day - j  # starting from 10, then going backwards
        # add a new row with the new day
        # month=i+1 # index starts from 0, for month +1
        day = firsthalf_day_index
        # append at the end of the dataframe
        list_toadd.append(datetime(2021, month_toadd, day))
        j -= 1
    return list_toadd


def get_required_date(df):
    schedule_date = []
    later_date = df['date'][len(df) - 1]
    later_days = 0
    for index, x in df.iterrows():
        if later_days > (later_date - x['date']).days:
            end_date = later_date - timedelta(days=later_days)
        else:
            end_date = x['date']
        date_list = pd.date_range(end=end_date - timedelta(days=7), periods=x['train']).tolist()
        schedule_date.append(date_list)
        later_days = x['train']
        later_date = x['date']
    df['schedule_date'] = schedule_date
    return df


def get_train_number(df, inventory, months):
    train_number = []
    for index, x in df.iterrows():
        real_demand = x['volume'] - inventory[months[x['month'] - 1]]
        if real_demand > 0:
            train_number.append(math.ceil(real_demand/11.5))
            inventory[months[x['month'] - 1]] = 0
        else:
            train_number.append(0)
            inventory[months[x['month'] - 1]] = inventory[months[x['month'] - 1]] - x['volume']
    df['train'] = train_number
    return df


def get_customer_demandV2(demand_df):
    inventory = demand_df.loc['inventory']
    demand_df.drop(index=["inventory", "demand"], inplace=True)
    months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October',
              'November', 'December']
    demand_list = []
    for index, row in demand_df.iterrows():
        for item in row:
            if item['eta'] != '':
                demand_list.append([datestr2datetime(item['eta'], "%b %d, %Y"), item['volume']])

    year_demand_df = pd.DataFrame(demand_list, columns=['date', 'volume'])
    year_demand_df = year_demand_df.groupby(by=["date"]).sum()
    year_demand_df.reset_index(inplace=True)
    year_demand_df.sort_values('date', inplace=True)
    year_demand_df['month'] = year_demand_df['date'].apply(lambda x: x.month)
    year_demand_df = get_train_number(year_demand_df, inventory, months)
   # year_demand_df.sort_values('date', ascending=False, inplace=True)
    year_demand_df.sort_values('date', ascending=True, inplace=True)
    year_demand_df=year_demand_df[['date','volume']]
    # year_demand_df = get_required_date(year_demand_df)
    # departure_df = pd.DataFrame(sorted([item for sublist in year_demand_df['schedule_date'] for item in sublist]),
    #                             columns=['departure date'])
    return year_demand_df #departure_df

def get_wholeyear_demand(start_datestr,end_datestr,year_demand_df):
   # start_datestr = "2021-01-01"
  #  end_datestr = "2021-12-31"
    #site_name = ("Shantz").lower()
    
    start_datetime = datestr2datetime(start_datestr)
    end_datetime = datestr2datetime(end_datestr)
    datetime_ind=datestr2datetime(start_datestr)
    
    whole_year_datetime = pd.DataFrame()
    whole_year_datetime['date']= start_datetime 
    whole_year_datetime['volume']= 0
    while datetime_ind <= end_datetime:
        whole_year_datetime = whole_year_datetime.append({'date' : datetime_ind, 'volume' : 0},ignore_index = True)
        datetime_ind += timedelta(days=1)
    
    #merge whole_year_datetime with year_demand_df    
    resultdemand_df = pd.merge(whole_year_datetime, year_demand_df, how="left",on="date")
    resultdemand_df['volume_y']=resultdemand_df['volume_y'].fillna(0)
    resultdemand_df.drop(['volume_x'],axis=1,inplace=True)
    resultdemand_df=resultdemand_df.rename(columns={"volume_y": "volume"})
    resultdemand_df['volume']=resultdemand_df['volume']*1000
    
    return resultdemand_df

start_datestr = "2021-01-01"
end_datestr = "2021-12-31"

demand_df = pd.read_json("data/pct_inventory.json")
monthly_solid_demand = get_customer_demandV2(demand_df)

whole_year_demand_df=get_wholeyear_demand(start_datestr, end_datestr,monthly_solid_demand)

# demand plot from PCT
whole_year_demand_df.plot(x ='date', y='volume', kind = 'line')  #'scatter')
#%%
def get_wholeyear_demand(start_datestr,end_datestr,year_demand_df):
   # start_datestr = "2021-01-01"
  #  end_datestr = "2021-12-31"
    #site_name = ("Shantz").lower()
    
    start_datetime = datestr2datetime(start_datestr)
    end_datetime = datestr2datetime(end_datestr)
    datetime_ind=datestr2datetime(start_datestr)
    
    whole_year_datetime = pd.DataFrame()
    whole_year_datetime['date']= start_datetime 
    whole_year_datetime['volume']= 0
    while datetime_ind <= end_datetime:
        whole_year_datetime = whole_year_datetime.append({'date' : datetime_ind, 'volume' : 0},ignore_index = True)
        datetime_ind += timedelta(days=1)
    
    #merge whole_year_datetime with year_demand_df    
    resultdemand_df = pd.merge(whole_year_datetime, year_demand_df, how="left",on="date")
    resultdemand_df['volume_y']=resultdemand_df['volume_y'].fillna(0)
    resultdemand_df.drop(['volume_x'],axis=1,inplace=True)
    resultdemand_df=resultdemand_df.rename(columns={"volume_y": "volume"})
    resultdemand_df['volume']=resultdemand_df['volume']*1000
    
    return resultdemand_df
#%%

import math 
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
import seaborn as sns; sns.set()
import pandas as pd
from IPython.display import display
import collections
import json

from qbstyles import mpl_style

mpl_style(dark=False)

#%%

# length of the episode 
lenT=len(whole_year_demand_df)
print(lenT)
#%%
# define the environment

class State(object):
 #   def __init__(self, T, demand_history, t = 0):
    def __init__(self, T, demand_history, t = 0):
         #(action[0]+1.0)*11500.0/2.0 
        # need to normalize the states to [-1,+1] range too
        # at factory site
        self.factory_silo= 12000.0*2.0/32000.0-1.0     # silo level  range is from 0 to 32000
        self.factory_stock = 60000.0*2.0/200000.0-1.0  # stock level    range is from 0 to 200000
        # demand info
        self.demand_history = 0.0*2.0/100000.0-1.0  #demand_history  # adding demand to state   range is from 0 to 100000
        # at PCT warehouse site       
        self.warehouse_stock = 50000.0*2.0/85000.0-1.0  # PCT warehouse stock level   range is from 0 to 85000
        
        # demand history, check if we just need to use one value or a history of values
     #   self.demand_history = demand_history
        self.T = T
        self.t = t

    def to_array(self):
        return np.concatenate( ([self.factory_silo],[self.factory_stock], [self.warehouse_stock], [self.demand_history]))  #, [self.t]) )

    def stock_levels(self):
        return np.concatenate( ([self.factory_silo],[self.factory_stock], [self.warehouse_stock]) )

class Action(object):
    def __init__(self):
     #   self.production_level = 0
        self.shippings_to_warehouses = 0
        self.factory_reclaim = 0
        self.factory_stockpile = 0

class SupplyChainEnvironment(object):
    def __init__(self):
        self.T = lenT               # episode duration
  
        self.unit_price = 150     # unit price for sulphur in dollars 
        self.unit_cost = 40       # unit cost for production in dollars

        self.production_level = 1650  # MT  assume it's constant
        
        self.factory_storage_capacity =200000  # MT
        self.factory_silo_capacity = 32000
        self.warehouse_storage_capacity = 85000 # PCT 
        self.shipping_capacity =11500  # each time maximum shipping is 11500
        
        self.factory_storage_costs= 0.0
        self.warehouse_storage_costs = 0.16 # per MT per day 
        self.transportation_costs = 5   # $15 per unit MT
        self.penalty_unit_cost = self.unit_price  # penalty if not meeting demand, use the same price
        self.stockpile_cost = 5.0
        self.reclaim_cost = 5.0
        self.reset()

    def reset(self): #, demand_history_len = 4):
       # self.demand_history=0.0
      #  self.demand_history=[]
    #    self.demand_history = [0 for i in range(self.T)] 
        self.t = 0

    # demand at time t at warehouse j
    # def demand(self,  t): # just one demand from warehouse
       
    #     #demandPCT=np.array([0,0,0,0,0,0,0,0,0,0,12000,0,0,0,0,0,0,23500,0,0,0,0,0,0,25000,0])
    #     return demandPCT[t]*2.0/100000.0-1.0   # normalized to [-1,1]
    def demand(self,  t): # demand in the next day
         
        return whole_year_demand_df['volume'].iloc[t]
    
    def initial_state(self):
        
        return State(self.T,demand_history=-1.0) #, list(self.demand_history))

    def step(self, state, action):
        #demands = np.fromfunction(lambda j: self.demand(j+1, self.t), (self.warehouse_num,), dtype=int)
        #state.demand_hisotry = self.demand(self.t)
        # calculating the reward (profit)
        #unnormalize state first be aware normalized range is [-1,+1]
      #demand range is [0,100000]
        unnormalizen_demand = (state.demand_history+1.0)*100000.0/2.0
        # factory stock is [0,200000]
        unnormalized_factory_stock= (state.factory_stock+1.0)*200000.0/2.0
        #silo range [15000,32000]
        unnormalized_factory_silo = 32000.0-(1.0-state.factory_silo)*(32000.0-15000.0)/2.0
        # PCT stock range [0,85000]
        unnormalized_warehouse_stock= (state.warehouse_stock+1.0)*85000.0/2.0
        total_stockpile_cost = action.factory_stockpile*self.stockpile_cost
        total_reclaim_cost = action.factory_reclaim*self.reclaim_cost
        
        total_revenue = self.unit_price * unnormalizen_demand  # only one demand value
        total_production_cost = self.unit_cost * self.production_level
        total_storage_cost = self.factory_storage_costs* unnormalized_factory_stock + self.warehouse_storage_costs*unnormalized_warehouse_stock# factory and warehouse storage cost
       
        total_penalty_cost = - self.penalty_unit_cost * (min(unnormalized_warehouse_stock,0))  # needs to check
           
        total_transportation_cost = self.transportation_costs*action.shippings_to_warehouses
        reward = total_revenue  - total_storage_cost - total_penalty_cost - total_transportation_cost -total_stockpile_cost-total_reclaim_cost
       # reward = total_revenue - total_production_cost - total_storage_cost - total_penalty_cost - total_transportation_cost
       # reward = total_revenue  - total_storage_cost - total_penalty_cost 

        # calculating the next state
        next_state = State(self.T, self.t)
        # normalize the states
        next_state.factory_stock =(min((unnormalized_factory_stock + action.factory_stockpile-action.factory_reclaim), self.factory_storage_capacity))*2.0/200000.0-1.0 
        next_state.warehouse_stock = (min(state.warehouse_stock+action.shippings_to_warehouses-state.demand_history,self.warehouse_storage_capacity))*2.0/85000.0-1.0
        next_state.factory_silo = (min(self.production_level+ unnormalized_factory_silo-action.factory_stockpile+action.factory_reclaim-action.shippings_to_warehouses,self.factory_silo_capacity))*2.0/32000.0-1.0
        #next_state.demand_history = demands  #.append(demands)
        next_state.demand_history = self.demand(self.t)  #(self.demand(self.t)+1.0)*2.0/100000.0-1.0
        
        self.t += 1
        #next_state.demand_history=demands  #.append(demands)
        

        return next_state, reward, self.t == self.T - 1
    
#%%
# # visualize demand functions for PCT
# env = SupplyChainEnvironment()
# #demands = np.fromfunction(lambda j, t: env.demand(j, t), (env.warehouse_num, env.T), dtype=int)
# #demand1=demands[0]
# demandPCT=[0,0,0,0,0,0,0,0,0,0,12000,0,0,0,0,0,0,23500,0,0,0,0,0,0,25000,0,0,0,0,0,0,12000,0,0,0,0,0,0,22000,0,0,0]
# print(len(demandPCT))
# demandPCT=np.array(demandPCT)
# plt.figure(figsize=(16, 5))
# plt.xlabel("Time step")
# plt.ylabel("Demand")
# plt.plot(range(env.T), demandPCT)  


#%%
def prepare_metric_plot(plots_n, n, ylabel):
    plt.subplot(plots_n, 1, n)
    plt.ylabel(ylabel)
    plt.tick_params(axis='x', which='both', bottom=True, top=True, labelbottom=False)


def visualize_transitions(transitions):
    #state_trace, action_trace, reward_trace = (transitions[:,0], transitions[:,1], transitions[:,2])
    plots_n = 9
    mpl.rcParams['lines.linewidth'] = 2    
    print(f"Return is {sum(transitions[:,7])}")

    fig = plt.figure(figsize=(8, 12))
    # state plots
    prepare_metric_plot(plots_n, 1, "Silo,\n Factory")
    #plt.plot(range(42), list(map(lambda s: s[0], state_trace)), c='yellow', alpha=0.5)
   # plt.plot(range(lenT), list((transitions[:,0]+1.0)*32000.0/2.0), c='yellow', alpha=0.5) 
    plt.plot(range(lenT), list(32000.0-(1.0-transitions[:,0])*(32000.0-15000.0)/2.0), c='yellow', alpha=0.5) 
    
 
    prepare_metric_plot(plots_n, 2, "Stock,\n Factory")
    plt.plot(range(lenT), list((transitions[:,1]+1.0)*200000.0/2.0), c='purple', alpha=0.5) 
    
    prepare_metric_plot(plots_n, 3, "Stock,\n PCT")
    plt.plot(range(lenT), list((transitions[:,2]+1.0)*85000.0/2.0), c='orange', alpha=0.5)
    
    prepare_metric_plot(plots_n, 4, "Demand,\n PCT")
    plt.plot(range(lenT), list((transitions[:,3]+1.0)*100000.0/2.0), c='orange', alpha=0.5)
    # prepare_metric_plot(plots_n, 4, "Demand,\n PCT")
    # plt.plot(range(42), demandPCT, c='red', alpha=0.5)
    
       
    # prepare_metric_plot(plots_n, 5, "Shipping")
    # plt.plot(range(42), list((transitions[:,4]+1.0)*11500.0/2.0), c='green', alpha=0.5)
    
    # prepare_metric_plot(plots_n, 6, "Reclaim,\n Factory")
    # plt.plot(range(42), list((transitions[:,5]+1.0)*1650.0/2.0), c='cyan', alpha=0.5)
    
    # prepare_metric_plot(plots_n, 7, "Stockpile,\n Factory ")
    # plt.plot(range(42), list((transitions[:,6]+1.0)*1650.0/2.0), c='magenta', alpha=0.5)
    
    prepare_metric_plot(plots_n, 5, "Shipping")
    plt.plot(range(lenT), list((transitions[:,4])*11500.0), c='green', alpha=0.5)
    
    prepare_metric_plot(plots_n, 6, "Reclaim,\n Factory")
    plt.plot(range(lenT), list((transitions[:,5])*1500.0), c='cyan', alpha=0.5)
    
    prepare_metric_plot(plots_n, 7, "Stockpile,\n Factory ")
    plt.plot(range(lenT), list((transitions[:,6])*1500.0), c='magenta', alpha=0.5)
 
    
    prepare_metric_plot(plots_n, 8, "Profit")
    plt.plot(range(lenT), list(transitions[:,7]), c='red', alpha=0.9, linewidth=2)

    plt.subplot(plots_n, 1, 9)
    plt.ylabel("Cumulative\nprofit")
   # plt.ylim(0, 10000)
    plt.plot(range(lenT), np.cumsum(transitions[:,7]), c='red', alpha=0.9, linewidth=2)
    plt.xlabel("Time step")


def save_transitions(transitions):
    #state_trace, action_trace, reward_trace = (transitions[:,0], transitions[:,1], transitions[:,2])
   
    fact_silo=list(32000.0-(1.0-transitions[:,0])*(32000.0-15000.0)/2.0)    
    fact_stock= list((transitions[:,1]+1.0)*200000.0/2.0)
    PCT_stock= list((transitions[:,2]+1.0)*85000.0/2.0)
    demand_state=list((transitions[:,3]+1.0)*100000.0/2.0) 
    fact_production= 1650  #list(map(lambda a: a.production_level, action_trace))    
    # shipping=list((transitions[:,4]+1.0)*11500.0/2.0) 
    # reclaim=list((transitions[:,5]+1.0)*1650.0/2.0) 
    # Stockpile=list((transitions[:,6]+1.0)*1650.0/2.0)
    shipping=list((transitions[:,4])*11500.0) 
    reclaim=list((transitions[:,5])*1650.0) 
    Stockpile=list((transitions[:,6])*1650.0)
    profit=list(transitions[:,7])
    time= range(42)
    savedtransition = pd.DataFrame(
    {'time': time,
     'factory_stock': fact_stock,
     'factory_silo': fact_silo,
     'PCT_stock': PCT_stock,
     'demand':demand_state,
 #    'demand':demandPCT, # this is hardcoded, need to include demand in state, so get info from state trace directly
     'factory_production': fact_production,
     'factory_shipping': shipping,
     'factory_reclaim': reclaim,
     'factory_stockpiling': Stockpile,
     'profit': profit     
    })
    return savedtransition      


#%%  Optimizing the Policy Using Reinforcement Learning / RLlib     
import numpy as np
import gym
#from gym.spaces import Box
from gym import spaces
#%%

# space = spaces.Tuple((
#   spaces.Discrete(2),
#   spaces.Discrete(2),
#   spaces.Box(low=0, high=1, shape=(2, 2))))

# print(space.sample())

#%%
#test
# env = gym.make("Acrobot-v1")
# a = env.action_space
# print(a)                    #prints Discrete(3)
# print(a.n)    

# #%%
# # test
# #import gym
# env = gym.make('CartPole-v0')
# env.reset()
# for _ in range(1000):
#     env.render()
#     env.step(env.action_space.sample()) # take a random action
# env.close()  
#%%
#State
#self.factory_silo=12000     # silo level
#self.factory_stock = 60000  # stock level
#self.demand_history = 0  #demand_history  # adding demand to state 
#self.warehouse_stock = 50000.0  # 
#Action
#self.shippings_to_warehouses = 0
#self.factory_reclaim = 0
#self.factory_stockpile = 0

# high = np.array([self.x_threshold * 2,
#                          np.finfo(np.float32).max,
#                          self.theta_threshold_radians * 2,
#                          np.finfo(np.float32).max],
#                         dtype=np.float32)

# self.action_space = spaces.Discrete(2)
# self.observation_space = spaces.Box(-high, high, dtype=np.float32)

#%%

# gym environment adapter
class SimpleSupplyChain(gym.Env):
    def __init__(self):
        self.reset()
       # self.action_space = Box(low=-1.0, high=1.0, shape=(3, ), dtype=np.float32)
       # self.action_space = spaces.Tuple(spaces.Discrete(2),spaces.Discrete(2),spaces.Discrete(2))
       # self.action_space = [spaces.Discrete(2),spaces.Discrete(2),spaces.Discrete(2)]
        self.action_space =spaces.MultiDiscrete(np.array([2,2,2]))
    #    self.action_space = Box((np.array([0.0,0.0,0.0]), np.array([+11500.0,+1650.0,+1650.0]))
       # self.observation_space = Box(-10000, 10000, shape=(len(self.supply_chain.initial_state().to_array()), ), dtype=np.float32)
       # self.observation_space = Box(0.0, 200000.0, shape=(5, ), dtype=np.float32)
        self.observation_space = spaces.Box(-1.0, 1.0, shape=(4, ), dtype=np.float32)
      #  self.action_space = gym.spaces.Discrete(3)
       # self.observation_space = Box(-10000, 10000, shape=(len(self.supply_chain.initial_state().to_array()), ), dtype=np.float32)
      #  self.observation_space = gym.spaces.Discrete(5)
        
        
    def reset(self):
        self.supply_chain = SupplyChainEnvironment()
        self.state = self.supply_chain.initial_state()
        return self.state.to_array()

    def step(self, action):
        action_obj = Action()
        #action_obj.production_level = action[0]
        #action_obj.shippings_to_warehouses = action[1:]
        # here the real value for the action, change from normalized to real value
        # action_obj.shippings_to_warehouses = action[0]
        # action_obj.factory_reclaim = action[1]
        # action_obj.factory_stockpile = action[2]
        # below is for discrete space from -1 to +1
       # action_obj.shippings_to_warehouses = (action[0]+1.0)*11500.0/2.0
       # action_obj.factory_reclaim = (action[1]+1.0)*1650.0/2.0
      #  action_obj.factory_stockpile = (action[2]+1.0)*1650.0/2.0
        
        action_obj.shippings_to_warehouses = (action[0])*11500.0
        action_obj.factory_reclaim = (action[1])*1500.0
        action_obj.factory_stockpile = (action[2])*1500.0
        #print(action_obj.shippings_to_warehouses)
        #print(action_obj.factory_reclaim)
        #print(action_obj.factory_stockpile)
        self.state, reward, done = self.supply_chain.step(self.state, action_obj)
        return self.state.to_array(), reward, done, {}
    
  #  def render(self, mode='human', close=False):
   #     # Render the environment to the screen
  #      profit = self.reward
        #print(f'Profit:{profit}')
#%%
# test SimpleSupplyChain envionment
# seems OK
# env1=SimpleSupplyChain()
# obs=env1.reset()
# print(obs)
# action=[0,1.0,0]   # shipping, reclaim, stockpile
# obs, rewards, dones, info = env1.step(action)
# print(obs)
# print(rewards)
# print(dones)
#%%
#from stable_baselines import PPO2
import stable_baselines
from stable_baselines import PPO2
from stable_baselines.common.policies import MlpPolicy

env1=SimpleSupplyChain()

env = stable_baselines.common.vec_env.DummyVecEnv([lambda: env1])


model = PPO2(MlpPolicy, env, verbose=False)

#model.learn(total_timesteps=lenT*300000)
#model.save("supplydemand_PPO2baselineV2")

# need to train for multiple episodes
#%%  test vectorized env




#%%
model = PPO2.load("supplydemand_PPO2baselineV2")
obs = env1.reset()
#transitions_rl = []
transitions_init = []
for i in range(lenT):  # actually only 42 steps
    action, _states = model.predict(obs)
   # print(action[0][0])
   # print(action[0][1])
    # 
    print("action:",action)
    obs, rewards, dones, info = env.step(action)
    print("obs:",obs)
    print("rewards:",rewards)
   # transitions_rl.append([np.column_stack([obs, action, rewards]))
    transitions_init.append(np.column_stack([obs, action, rewards]).flatten())
              
              
visualize_transitions(np.array(transitions_init))


result_df=save_transitions(np.array(transitions_init))
#%%
#transitions=np.array(transitions_init)
#transitions[:,2]


# def visualize_transitions(transitions):
#     #state_trace, action_trace, reward_trace = (transitions[:,0], transitions[:,1], transitions[:,2])
#     plots_n = 9
#     mpl.rcParams['lines.linewidth'] = 2    
#     print(f"Return is {sum(transitions[:,8])}")

#     fig = plt.figure(figsize=(8, 12))
#     # state plots
#     prepare_metric_plot(plots_n, 1, "Silo,\n Factory")
#     #plt.plot(range(42), list(map(lambda s: s[0], state_trace)), c='yellow', alpha=0.5)
#     plt.plot(range(42), list(transitions[:,0]), c='yellow', alpha=0.5)    
 
#     prepare_metric_plot(plots_n, 2, "Stock,\n Factory")
#     plt.plot(range(42), list(transitions[:,1]), c='purple', alpha=0.5) 
    
#     prepare_metric_plot(plots_n, 3, "Stock,\n PCT")
#     plt.plot(range(42), list(transitions[:,2]), c='orange', alpha=0.5)
    
 
#     prepare_metric_plot(plots_n, 4, "Demand,\n PCT")
#     plt.plot(range(42), demandPCT, c='red', alpha=0.5)
    
       
#     prepare_metric_plot(plots_n, 5, "Shipping")
#     plt.plot(range(42), list(transitions[:,4]), c='green', alpha=0.5)
    
#     prepare_metric_plot(plots_n, 6, "Reclaim,\n Factory")
#     plt.plot(range(42), list(transitions[:,5]), c='cyan', alpha=0.5)
    
#     prepare_metric_plot(plots_n, 7, "Stockpile,\n Factory ")
#     plt.plot(range(42), list(transitions[:,6]), c='magenta', alpha=0.5)
 
    
#     prepare_metric_plot(plots_n, 8, "Profit")
#     plt.plot(range(42), list(transitions[:,7]), c='red', alpha=0.9, linewidth=2)

#     plt.subplot(plots_n, 1, 9)
#     plt.ylabel("Cumulative\nprofit")
#    # plt.ylim(0, 10000)
#     plt.plot(range(42), np.cumsum(transitions[:,8]), c='red', alpha=0.9, linewidth=2)
#     plt.xlabel("Time step")


# def save_transitions(transitions):
#     #state_trace, action_trace, reward_trace = (transitions[:,0], transitions[:,1], transitions[:,2])
   
#     fact_stock=list(transitions[:,0])    
#     fact_silo= list(transitions[:,1])
#     PCT_stock= list(transitions[:,2])
#     demand_state=list(transitions[:,3]) 
#     fact_production= 1650  #list(map(lambda a: a.production_level, action_trace))    
#     shipping=list(transitions[:,5]) 
#     reclaim=list(transitions[:,6]) 
#     Stockpile=list(transitions[:,7])
#     profit=list(transitions[:,8])
#     time= range(42)
#     savedtransition = pd.DataFrame(
#     {'time': time,
#      'factory_stock': fact_stock,
#      'factory_silo': fact_silo,
#      'PCT_stock': PCT_stock,
#      'demand':demand_state,
#  #    'demand':demandPCT, # this is hardcoded, need to include demand in state, so get info from state trace directly
#      'factory_production': fact_production,
#      'factory_shipping': shipping,
#      'factory_reclaim': reclaim,
#      'factory_stockpiling': Stockpile,
#      'profit': profit     
#     })
#     return savedtransition
# # # tracing the policy
# # env = SimpleSupplyChain()
# # #state = env.initial_state()
# # state = env.reset()
# # transitions_rl = []
# # for t in range(42):
# #     action, state = model.predict(state)
# #    # action  policy.compute_single_action( state.to_array() , state=[] ) 
# #     print("action:",action)
# #     print("state:",state)
# #     action_obj=Action()
# #     action_obj.shippings_to_warehouses = action[0]
# #     action_obj.factory_reclaim = action[1]
# #     action_obj.factory_stockpile = action[2]
# #     state, reward,info = env.step(action)
# #     transitions_rl.append([state, action, reward])

#%%


#%%  Trying to use DDPG to train the model

# from stable_baselines.ddpg.policies import MlpPolicy
# from stable_baselines.common.noise import NormalActionNoise, OrnsteinUhlenbeckActionNoise, AdaptiveParamNoiseSpec
# from stable_baselines import DDPG


# # the noise objects for DDPG
# n_actions = env.action_space.shape[-1]
# param_noise = None
# action_noise = OrnsteinUhlenbeckActionNoise(mean=np.zeros(n_actions), sigma=float(0.5) * np.ones(n_actions))

# model = DDPG(MlpPolicy, env, verbose=1, param_noise=param_noise, action_noise=action_noise)
# model.learn(total_timesteps=400000)
# model.save("ddpg_supplydemand")

# del model # remove to demonstrate saving and loading

# model = DDPG.load("ddpg_mountain")

# obs = env.reset()
# while True:
#     action, _states = model.predict(obs)
#     obs, rewards, dones, info = env.step(action)
#     env.render()


# #%%

# env=SimpleSupplyChain()

# print(env.action_space)
# print(env.observation_space)

# from stable_baselines.common.env_checker import check_env
# check_env(SimpleSupplyChain)

# #%% Trying to use Q learning
# # env=SimpleSupplyChain()
# # action_space_size = 3 #env.action_space.n
# # state_space_size = 5 #env.observation_space.n

# # q_table = np.zeros((state_space_size, action_space_size))

# # print(q_table)

# #%%

# # num_episodes = 1000
# # max_steps_per_episode = 10 # but it won't go higher than 1

# # learning_rate = 0.1
# # discount_rate = 0.99

# # exploration_rate = 1
# # max_exploration_rate = 1
# # min_exploration_rate = 0.01

# # exploration_decay_rate = 0.01 #if we decrease it, will learn slower
# # #%%

# # rewards_all_episodes = []

# # # Q-Learning algorithm
# # for episode in range(num_episodes):
# #     state = env.reset()
    
# #     done = False
# #     rewards_current_episode = 0
    
# #     for step in range(max_steps_per_episode):
        
# #         # Exploration -exploitation trade-off
# #         exploration_rate_threshold = random.uniform(0,1)
# #         if exploration_rate_threshold > exploration_rate: 
# #             action = np.argmax(q_table[state,:])
# #         else:
# #             action = env.action_space.sample()
            
# #         new_state, reward, done, info = env.step(action)
        
# #         # Update Q-table for Q(s,a)
# #         q_table[state, action] = (1 - learning_rate) * q_table[state, action] + \
# #             learning_rate * (reward + discount_rate * np.max(q_table[new_state,:]))
            
# #         state = new_state
# #         rewards_current_episode += reward
        
# #         if done == True: 
# #             break
            
# #     # Exploration rate decay
# #     exploration_rate = min_exploration_rate + \
# #         (max_exploration_rate - min_exploration_rate) * np.exp(-exploration_decay_rate * episode)
    
# #     rewards_all_episodes.append(rewards_current_episode)
    
# # # Calculate and print the average reward per 10 episodes
# # rewards_per_thousand_episodes = np.split(np.array(rewards_all_episodes), num_episodes / 100)
# # count = 100
# # print("********** Average  reward per thousand episodes **********\n")

# # for r in rewards_per_thousand_episodes:
# #     print(count, ": ", str(sum(r / 100)))
# #     count += 100
    
# # # Print updated Q-table
# # print("\n\n********** Q-table **********\n")
# # print(q_table)