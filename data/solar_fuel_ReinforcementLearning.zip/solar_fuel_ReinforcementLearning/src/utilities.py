"""
Module of the utility functions used in the project
"""
import argparse
import random
import numpy as np
import torch
import yaml

def parse_parameters():
    """_summary_

    Returns:
        list: _description_
    """
    parser = argparse.ArgumentParser(prog="RL Solar-H2 Production Pipeline",
                                     formatter_class=argparse.ArgumentDefaultsHelpFormatter,
                                     description="Use reinforcement learning to optmize H2"\
                                                  "production using solar energy")
    parser.add_argument("--experiment_name",
                    help="Name of the experiment running",
                    default="test_experiment",
                    type=str)
    parser.add_argument("--eval_freq",
                    help="Frequency of evaluation in training",
                    default=50000,
                    type=int)
    parser.add_argument("--steps_scale_factor",
                    help="Scaling factor on the steps learning",
                    default=3500,
                    type=int)
    parser.add_argument("--initial_month_train",
                    help="Initial month for training",
                    default='Jan',
                    type=str)
    parser.add_argument("--initial_month_test",
                    help="Initial month for training",
                    default='Jan',
                    type=str)
    parser.add_argument("--num_of_months_train",
                    help="Number of months on the training",
                    default=1,
                    type=int)
    parser.add_argument("--num_of_months_test",
                    help="Number of months on the training",
                    default=1,
                    type=int)
    parser.add_argument("--curtail_unit_cost",
                    help="Curtailment unit cost",
                    default=5,
                    type=float)
    parser.add_argument("--h2_demand",
                    help="hydrogen demmand",
                    default=64400,
                    type=float)
    parser.add_argument("--battery_storage_capacity",
                    help="Total battery storage capacity",
                    default=5000,
                    type=float)
    parser.add_argument("--electrolyzer_cost",
                    help="Eletrclyzer cost",
                    default=0,
                    type=float)
    parser.add_argument("--h2_price",
                    help="Price of hydrogen",
                    default=5,
                    type=float)
    parser.add_argument("--penalty_unit_cost",
                    help="Penalty for not meeting demand",
                    default=5,
                    type=float)
    parser.add_argument("--hyperparameters_optimization",
                    help="Boolean to activate hyperparameters optimization",
                    default=False,
                    type=str2bool)

    # extract the parameters from the parser
    args = parser.parse_args()
    experiment_name = args.experiment_name
    eval_freq = args.eval_freq
    steps_scale_factor = args.steps_scale_factor
    initial_month_train = args.initial_month_train
    initial_month_test = args.initial_month_test
    num_of_months_train = args.num_of_months_train
    num_of_months_test = args.num_of_months_test
    curtail_unit_cost = args.curtail_unit_cost
    h2_demand = args.h2_demand
    battery_storage_capacity = args.battery_storage_capacity
    electrolyzer_cost = args.electrolyzer_cost
    h2_price = args.h2_price
    penalty_unit_cost = args.penalty_unit_cost
    hyperparameters_optimization = args.hyperparameters_optimization
    args = vars(args)

    return [experiment_name,
            eval_freq,
            steps_scale_factor,
            initial_month_train,
            initial_month_test,
            num_of_months_train,
            num_of_months_test,
            curtail_unit_cost,
            h2_demand,
            battery_storage_capacity,
            electrolyzer_cost,
            h2_price,
            penalty_unit_cost,
            hyperparameters_optimization,
            args]

def normalize_val(val, lower_lim, upper_lim):
    """
    Parameters
    ----------
    val : float
        DESCRIPTION. value to be normalized
    lower_lim : Int
        DESCRIPTION. Lower limit
    upper_lim : Int
        DESCRIPTION. Upper Limit
    Returns
    -------
    Normalized Value
    """
    return(val-lower_lim)/(upper_lim-lower_lim)

def denormalize_val(norm_val, lower_lim, upper_lim):
    """
    Denormalizes norm_val
    Parameters
    ----------
    norm_val : Float
        DESCRIPTION. Normalized Val
    lower_lim : Int
        DESCRIPTION. Lower Limit
    upper_lim : Int
        DESCRIPTION. Upper Limit
    Returns
    -------
    Denormalized Value.
    """
    return norm_val*(upper_lim-lower_lim) + lower_lim

def str2bool(user_input):  # sourcery skip: raise-specific-error
    """
    Boolean ArgParse options are confusing by default: They just just --some-option
    _without_ giving a True or False value; if the switch is present, such as
    --some-option, then it becomes True. If someone gives '--some-option False'
    the option will still evaluate as True! This method changes this default
    behavior so that boolean command line args match expected behavior:
    '--some-option=True' will evaluate to True and '--some-option=False'
    will evaluate to False.
    """
    if isinstance(user_input, bool):
        return user_input
    if user_input.lower() in ('yes', 'true', 't', 'y', '1'):
        return True
    elif user_input.lower() in ('no', 'false', 'f', 'n', '0'):
        return False
    else:
        raise Exception('Boolean value expected.')

def set_seed(seed=34):
    """_summary_

    Args:
        seed (int, optional): Initial seed for all random processes. Defaults to 34.
    """
    print(f"Random seed is : {seed}")
    np.random.seed(seed)
    random.seed(seed)
    torch.manual_seed(seed)
    # Determinsm for Pytorch
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

def parse_yaml_props(filename):
    """
    parse_yaml_props function is defined to parse data from YAML file
    :filename : YAML file name input
    :parsed_yaml : parsed properties from YAML file as dictionaryas output.
    """
    with open(filename, 'r') as stream:
        try:
            parsed_yaml = yaml.safe_load(stream)
        except yaml.YAMLError as exc:
            print(exc)

    return parsed_yaml

def calculate_hourly_demand(whole_year_supply, total_demand, buffer_demand=5000):
    hours_without_sun = (len(whole_year_supply[0:24]) - np.count_nonzero(whole_year_supply[0:24]))
    total_demand=64400
    buffer_demand=5000

    adjusted_total_demand = total_demand
    adjusted_buffer_demand = adjusted_total_demand*0.20
    print(f"Total duration {len(whole_year_supply)}")
    print(f"Number of hours without sun: {hours_without_sun}")
    print(f"Total Demand: {total_demand}")
    print(f"Buffer Demand: {buffer_demand}")

    modeled_demand = np.empty(len(whole_year_supply))

    hourly_buffer_demand=adjusted_buffer_demand/hours_without_sun
    print(f"Hourly Buffer Demand: {hourly_buffer_demand}")

    remain_demand = adjusted_total_demand-adjusted_buffer_demand
    print(f"Remain Demand: {remain_demand}")

    normalize_solar_in = whole_year_supply/whole_year_supply.sum()
    modeled_demand = normalize_solar_in*remain_demand*31
    modeled_demand[modeled_demand == 0] = 900

    print(f'Total demand per day integrating the profile: {modeled_demand.sum()}')
    return modeled_demand
