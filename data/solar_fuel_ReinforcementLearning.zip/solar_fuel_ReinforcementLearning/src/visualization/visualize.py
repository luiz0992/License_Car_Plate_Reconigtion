"""
Created on Mon Feb 28 13:56:05 2022

Solar fuel optimization using Reinforcement learning

@author: Luiz F. G. dos Santos
"""

# from matplotlib import style
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt

from src.utilities import denormalize_val
from src.global_variables import MAX_SOLAR_IN,\
                                 MIN_SOLAR_IN,\
                                 MAX_BATTERY_STORAGE_CAPACITY,\
                                 MIN_BATTERY_STORAGE_CAPACITY

def prepare_metric_plot(plots_n, n, ylabel):
    """_summary_

    Args:
        plots_n (_type_): _description_
        n (_type_): _description_
        ylabel (_type_): _description_
    """
    plt.subplot(plots_n, 1, n)
    plt.ylabel(ylabel)
    plt.tick_params(axis='x', which='both', bottom=True, top=True, labelbottom=False)

def complete_plot(solar_in,
                  battery_level,
                  h2_demand,
                  rewards,
                  solar_to_battery,
                  solar_to_electrolyzer,
                  solar_to_curtail,
                  battery_to_electrolyzer,
                  reward_adjusted,
                  penalty_negative_battery_level,
                  penalty_excess_battery_level,
                  penalty_excess_production,
                  penalty_under_production,
                  penalty_amount_energy,
                  curtail_cost,
                  results_path,
                  save_results=True,
                  partial=True,
                  baseline_profit=None) -> None:
    """_summary_

    Args:
        plots_n (_type_): _description_
        n (_type_): _description_
        ylabel (_type_): _description_
    """
    plots_n = 6
    times_steps = range(len(rewards))
    mpl.rcParams['lines.linewidth'] = 2
    
    if partial:
        solar_in = solar_in[:100]
        battery_level = battery_level[:100]
        h2_demand=h2_demand[:100]
        rewards = rewards[:100]
        solar_to_battery = solar_to_battery[:100]
        solar_to_electrolyzer = solar_to_electrolyzer[:100]
        solar_to_curtail = solar_to_curtail[:100]
        battery_to_electrolyzer = battery_to_electrolyzer[:100]
        reward_adjusted = reward_adjusted[:100]
        penalty_negative_battery_level = penalty_negative_battery_level[:100]
        penalty_excess_battery_level = penalty_excess_battery_level[:100]
        penalty_excess_production = penalty_excess_production[:100]
        penalty_under_production = penalty_under_production[:100]
        penalty_amount_energy = penalty_amount_energy[:100]
        curtail_cost = curtail_cost[:100]
        rewards=rewards[:100]
        times_steps=times_steps[:100]
        if baseline_profit is not None:
            baseline_profit = baseline_profit[:100]
        
    h2_demand = np.array(h2_demand)
    print(f"Return is {sum(rewards)}")

    _fig = plt.figure(figsize=(15, 30))
    # state plots
    prepare_metric_plot(plots_n, 1, "Solar PV")
    plt.bar(times_steps, solar_in, color='black', alpha=0.5, label="Solar PV")
    plt.bar(times_steps, -solar_to_curtail, color='green', alpha=0.5, bottom=-solar_to_battery-solar_to_electrolyzer, label="Solar curtailment")
    plt.bar(times_steps, -solar_to_battery, color='magenta', alpha=0.5, bottom=-solar_to_electrolyzer, label="Solar to battery")
    plt.bar(times_steps, -solar_to_electrolyzer, color='cyan',alpha=0.5, bottom=0, label="Solar to electrolyzer")
    plt.legend()

    prepare_metric_plot(plots_n, 2, "H2 Production")
    plt.plot(times_steps, h2_demand,"--", color='black', alpha=0.5, label="H2 Demand")
    plt.fill_between(times_steps,y1=h2_demand*1.25, y2=h2_demand*0.75, color='black', alpha=0.1, label="H2 Demand")
    plt.bar(times_steps, solar_to_electrolyzer, color='cyan', alpha=0.5, bottom=battery_to_electrolyzer,label="Solar to electrolyzer")
    plt.bar(times_steps, battery_to_electrolyzer, color='purple', alpha=0.5, label="Battery to electrolyzer")
    plt.plot(times_steps, solar_to_electrolyzer+battery_to_electrolyzer, color='green', alpha=1, label="Total electrolyzer")
    plt.legend()

    prepare_metric_plot(plots_n, 3, "Battery level")
    plt.plot(times_steps, battery_level, c='brown', alpha=0.5)

    prepare_metric_plot(plots_n, 4, "Reward")
    plt.bar(times_steps, rewards, color='red', alpha=1, linewidth=2, label="Reward")
    plt.bar(times_steps, -penalty_negative_battery_level, color='blue', alpha=0.5, linewidth=2, bottom=-penalty_excess_battery_level-penalty_amount_energy-penalty_under_production-penalty_excess_production-curtail_cost, label="Negative battery level")
    plt.bar(times_steps, -penalty_excess_battery_level, color='black', alpha=0.5, linewidth=2, bottom=-penalty_amount_energy-penalty_under_production-penalty_excess_production-curtail_cost, label="Excess battery level")
    plt.bar(times_steps, -penalty_amount_energy, color='green', alpha=0.5, linewidth=2, bottom=-penalty_under_production-penalty_excess_production-curtail_cost, label="Amount energy")
    plt.bar(times_steps, -penalty_excess_production, color='magenta', alpha=0.5, linewidth=2, bottom=-curtail_cost, label="Excess production")
    plt.bar(times_steps, -penalty_under_production, color='brown', alpha=0.5, linewidth=2, bottom=-penalty_excess_production-curtail_cost, label="Under production")
    plt.bar(times_steps, -curtail_cost, color='yellow', alpha=0.5, linewidth=2, bottom=0, label="Curtailing")
    plt.legend()

    prepare_metric_plot(plots_n, 5, "Profit")
    plt.plot(times_steps, reward_adjusted, c='red', alpha=0.9, linewidth=2)

    plt.subplot(plots_n, 1, 6)
    plt.ylabel("Cumulative\nprofit")
   # plt.ylim(0, 10000)
    plt.plot(times_steps, np.cumsum(reward_adjusted),
             color='red', alpha=0.9, linewidth=2, label="RL model")
    if baseline_profit is not None:
        plt.plot(times_steps, np.cumsum(baseline_profit), 
                 color='black', alpha=0.9, linewidth=2, label="Baseline")
    plt.xlabel("Time step")
    plt.legend()

    if save_results:
        if partial:
            plt.savefig(f'{results_path}/result_plt_complete_partial.png', dpi=300)
        else:
            plt.savefig(f'{results_path}/result_plt_complete_full.png', dpi=300)

def solar_pv_diagnostics(solar_in,
                         rewards,
                         h2_demand,
                         solar_to_battery,
                         solar_to_electrolyzer,
                         solar_to_curtail,
                         battery_to_electrolyzer,
                         results_path,
                         save_results=True) -> None:

    plots_n = 2
    times_steps = range(len(rewards))
    mpl.rcParams['lines.linewidth'] = 2

    solar_in = solar_in[:100]
    rewards = rewards[:100]
    h2_demand=h2_demand[:100]
    solar_to_battery = solar_to_battery[:100]
    solar_to_electrolyzer = solar_to_electrolyzer[:100]
    solar_to_curtail = solar_to_curtail[:100]
    battery_to_electrolyzer = battery_to_electrolyzer[:100]
    rewards=rewards[:100]
    times_steps=times_steps[:100]

    _fig = plt.figure(figsize=(16, 20), dpi=300)
    # state plots
    prepare_metric_plot(plots_n, 1, "Solar PV")
    plt.bar(times_steps, solar_in, color='black', alpha=0.5, label="Solar PV")
    plt.bar(times_steps, -solar_to_curtail, color='green', alpha=0.5, bottom=-solar_to_battery-solar_to_electrolyzer, label="Solar curtailment")
    plt.bar(times_steps, -solar_to_battery, color='magenta', alpha=0.5, bottom=-solar_to_electrolyzer, label="Solar to battery")
    plt.bar(times_steps, -solar_to_electrolyzer, color='cyan',alpha=0.5, bottom=0, label="Solar to electrolyzer")
    plt.legend()

    prepare_metric_plot(plots_n, 2, "H2 Production")
    plt.plot(times_steps, h2_demand,"--", color='black', alpha=0.5, label="H2 Demand")
    plt.fill_between(times_steps,y1=h2_demand*1.25, y2=h2_demand*0.75, color='black', alpha=0.1, label="H2 Demand")
    plt.bar(times_steps[:100], solar_to_electrolyzer[:100], color='cyan', alpha=0.5, bottom=battery_to_electrolyzer[:100],label="Solar to electrolyzer")
    plt.bar(times_steps[:100], battery_to_electrolyzer[:100], color='purple', alpha=0.5, label="Battery to electrolyzer")
    plt.plot(times_steps, solar_to_electrolyzer+battery_to_electrolyzer, color='green', alpha=1, label="Total electrolyzer")
    plt.legend()

    if save_results:
        plt.savefig(f'{results_path}/solar_pv_diagnostics.png', dpi=300)

def reward_diagnostics(rewards,
                       penalty_negative_battery_level,
                       penalty_excess_battery_level,
                       penalty_excess_production,
                       penalty_under_production,
                       penalty_amount_energy,
                       curtail_cost,
                       results_path,
                       save_results=True) -> None:

    plots_n = 2
    times_steps = range(len(rewards))
    mpl.rcParams['lines.linewidth'] = 2
    print(f"Return is {sum(rewards)}")

    rewards = rewards[:100]
    penalty_negative_battery_level = penalty_negative_battery_level[:100]
    penalty_excess_battery_level = penalty_excess_battery_level[:100]
    penalty_excess_production = penalty_excess_production[:100]
    penalty_under_production = penalty_under_production[:100]
    penalty_amount_energy = penalty_amount_energy[:100]
    curtail_cost = curtail_cost[:100]
    rewards=rewards[:100]
    times_steps=times_steps[:100]

    _fig = plt.figure(figsize=(16, 20), dpi=300)
    # state plots

    prepare_metric_plot(plots_n, 1, "Reward")
    plt.bar(times_steps[:100], rewards[:100], color='red', alpha=0.9, linewidth=2, label="Reward")

    prepare_metric_plot(plots_n, 2, "Penalties")
    plt.bar(times_steps, -penalty_negative_battery_level, color='blue', alpha=0.9, linewidth=2, bottom=-penalty_excess_battery_level-penalty_amount_energy-penalty_under_production-penalty_excess_production-curtail_cost, label="Negative battery level")
    plt.bar(times_steps, -penalty_excess_battery_level, color='black', alpha=0.9, linewidth=2, bottom=-penalty_amount_energy-penalty_under_production-penalty_excess_production-curtail_cost, label="Excess battery level")
    plt.bar(times_steps, -penalty_amount_energy, color='green', alpha=0.9, linewidth=2, bottom=-penalty_under_production-penalty_excess_production-curtail_cost, label="Amount energy")
    plt.bar(times_steps, -penalty_excess_production, color='magenta', alpha=0.9, linewidth=2, bottom=-curtail_cost, label="Excess production")
    plt.bar(times_steps, -penalty_under_production, color='brown', alpha=0.9, linewidth=2, bottom=-penalty_excess_production-curtail_cost, label="Under production")
    plt.bar(times_steps, -curtail_cost, color='yellow', alpha=0.9, linewidth=2, bottom=0, label="Curtailing")
    plt.legend()

    if save_results:
        plt.savefig(f'{results_path}/reward_diagnostic.png', dpi=300)


def visualize_transitions(solar_in,
                          battery_level,
                          h2_demand,
                          rewards,
                          solar_to_battery,
                          solar_to_electrolyzer,
                          solar_to_curtail,
                          battery_to_electrolyzer,
                          reward_adjusted,
                          penalty_negative_battery_level,
                          penalty_excess_battery_level,
                          penalty_excess_production,
                          penalty_under_production,
                          penalty_amount_energy,
                          curtail_cost,
                          results_path,
                          save_results=True,
                          partial=True,
                          baseline_profit=None) -> None:

    """_summary_

    Args:
        transitions (_type_): _description_
        partial (_type_): _description_
        results_path (_type_): _description_
        min_solar_in (_type_): _description_
        max_solar_in (_type_): _description_
        min_battery_storage_capacity (_type_): _description_
        max_battery_storage_capacity (_type_): _description_
    """
    # print(solar_in)
    # solar_in = denormalize_val(solar_in,
    #                            MIN_SOLAR_IN,
    #                            MAX_SOLAR_IN)
    
    battery_level = denormalize_val(battery_level,
                                    MIN_BATTERY_STORAGE_CAPACITY,
                                    MAX_BATTERY_STORAGE_CAPACITY)

    complete_plot(solar_in=solar_in,
                  battery_level=battery_level,
                  h2_demand=h2_demand,
                  rewards=rewards,
                  solar_to_battery=solar_to_battery,
                  solar_to_electrolyzer=solar_to_electrolyzer,
                  solar_to_curtail=solar_to_curtail,
                  battery_to_electrolyzer=battery_to_electrolyzer,
                  reward_adjusted=reward_adjusted,
                  penalty_negative_battery_level=penalty_negative_battery_level,
                  penalty_excess_battery_level=penalty_excess_battery_level,
                  penalty_excess_production=penalty_excess_production,
                  penalty_under_production=penalty_under_production,
                  penalty_amount_energy=penalty_amount_energy,
                  curtail_cost=curtail_cost,
                  results_path=results_path,
                  save_results=save_results,
                  partial=partial,
                  baseline_profit=baseline_profit)

    solar_pv_diagnostics(solar_in=solar_in,
                         rewards=rewards,
                         h2_demand=h2_demand,
                         solar_to_battery=solar_to_battery,
                         solar_to_electrolyzer=solar_to_electrolyzer,
                         solar_to_curtail=solar_to_curtail,
                         battery_to_electrolyzer=battery_to_electrolyzer,
                         results_path=results_path,
                         save_results=save_results)

    reward_diagnostics(rewards=rewards,
                       penalty_negative_battery_level=penalty_negative_battery_level,
                       penalty_excess_battery_level=penalty_excess_battery_level,
                       penalty_excess_production=penalty_excess_production,
                       penalty_under_production=penalty_under_production,
                       penalty_amount_energy=penalty_amount_energy,
                       curtail_cost=curtail_cost,
                       results_path=results_path,
                       save_results=save_results)
