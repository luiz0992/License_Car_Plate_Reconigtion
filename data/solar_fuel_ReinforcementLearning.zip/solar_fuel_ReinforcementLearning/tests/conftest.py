import pytest

@pytest.fixture()
def fixture():
    return "some stuff"
