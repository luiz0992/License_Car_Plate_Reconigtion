def test_always_passes():
    assert True

def test_always_fails():
    assert False
